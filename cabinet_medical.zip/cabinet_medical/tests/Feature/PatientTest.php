<?php

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\User;
use App\Models\MedicalPatient;

class PatientTest extends TestCase
{
    public function test_can_create_patient()
    {
        $admin = User::factory()->create(['role' => 'admin']);
        
        $response = $this->actingAs($admin)->post('/patients', [
            'nom' => 'Dupont',
            'prenom' => 'Jean',
            'email' => 'jean@test.com',
            'telephone' => '0612345678',
            'date_naissance' => '1990-01-01',
            'adresse' => '1 rue de Paris',
            'sexe' => 'M'
        ]);
        
        $this->assertDatabaseHas('users', ['email' => 'jean@test.com']);
    }
}