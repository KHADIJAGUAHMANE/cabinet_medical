<?php

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\User;
use App\Models\MedicalPatient;
use App\Models\MedicalRendezVous;
use App\Models\MedicalConsultation;
use Illuminate\Foundation\Testing\RefreshDatabase;

class ConsultationTest extends TestCase
{
    use RefreshDatabase;

    public function test_can_create_consultation()
    {
        $medecin = User::factory()->create(['role' => 'medecin']);
        $patient = MedicalPatient::factory()->create();
        
        $rdv = MedicalRendezVous::create([
            'patient_id' => $patient->id,
            'user_id_medecin' => $medecin->id,
            'date_heure' => now(),
            'statut' => 'confirme',
            'motif' => 'Test'
        ]);
        
        $response = $this->actingAs($medecin)->post('/consultations', [
            'rendez_vous_id' => $rdv->id,
            'compte_rendu' => 'Patient en bonne santé',
            'diagnostic' => 'RAS',
            'traitement' => 'Repos'
        ]);
        
        $this->assertDatabaseHas('medical_consultations', [
            'compte_rendu' => 'Patient en bonne santé'
        ]);
    }
    
    public function test_can_create_ordonnance()
    {
        $consultation = MedicalConsultation::factory()->create();
        
        $response = $this->actingAs($consultation->medecin)
            ->post('/consultations/ordonnance/' . $consultation->id, [
                'medicaments' => 'Paracétamol 500mg',
                'posologies' => '3x par jour',
                'recommandations' => 'Repos'
            ]);
        
        $this->assertDatabaseHas('medical_ordonnances', [
            'medicaments' => 'Paracétamol 500mg'
        ]);
    }
}
