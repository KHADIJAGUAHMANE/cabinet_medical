

<?php $__env->startSection('title', 'Nouvelle consultation'); ?>

<?php $__env->startSection('content'); ?>
<div class="card shadow">
    <div class="card-header bg-white">
        <h5>Consultation - <?php echo e($rdv->patient->user->nom); ?> <?php echo e($rdv->patient->user->prenom); ?></h5>
        <p>Médecin: Dr. <?php echo e($rdv->medecin->nom); ?> <?php echo e($rdv->medecin->prenom); ?></p>
        <p>Date RDV: <?php echo e(\Carbon\Carbon::parse($rdv->date_heure)->format('d/m/Y H:i')); ?></p>
    </div>
    <div class="card-body">
        <form action="<?php echo e(route('consultations.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="rendez_vous_id" value="<?php echo e($rdv->id); ?>">

            <div class="mb-3">
                <label class="form-label">📝 Compte-rendu</label>
                <textarea name="compte_rendu" class="form-control" rows="5" required placeholder="Détail de la consultation..."></textarea>
            </div>

            <div class="mb-3">
                <label class="form-label">🩺 Diagnostic</label>
                <textarea name="diagnostic" class="form-control" rows="3" placeholder="Diagnostic établi..."></textarea>
            </div>

            <div class="mb-3">
                <label class="form-label">💊 Traitement</label>
                <textarea name="traitement" class="form-control" rows="3" placeholder="Traitement prescrit..."></textarea>
            </div>

            <button type="submit" class="btn btn-primary">Enregistrer la consultation</button>
            <a href="<?php echo e(route('rendezvous.index')); ?>" class="btn btn-secondary">Annuler</a>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cabinet_medical\resources\views/consultations/create.blade.php ENDPATH**/ ?>