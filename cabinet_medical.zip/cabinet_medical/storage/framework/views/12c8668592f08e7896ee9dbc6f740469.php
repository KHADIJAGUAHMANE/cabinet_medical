

<?php $__env->startSection('title', 'Gestion des disponibilités'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold">📅 Disponibilités des médecins</h2>
    <a href="<?php echo e(route('disponibilites.create')); ?>" class="btn btn-primary">
        <i class="bi bi-plus-circle"></i> Ajouter une disponibilité
    </a>
</div>

<div class="card shadow border-0 rounded-4">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>Médecin</th>
                        <th>Jour</th>
                        <th>Heure début</th>
                        <th>Heure fin</th>
                        <th>Statut</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $disponibilites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dispo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>Dr. <?php echo e($dispo->medecin->nom); ?> <?php echo e($dispo->medecin->prenom); ?></td>
                            <td><?php echo e(ucfirst($dispo->jour)); ?></td>
                            <td><?php echo e($dispo->heure_debut); ?></td>
                            <td><?php echo e($dispo->heure_fin); ?></td>
                            <td>
                                <span class="badge bg-<?php echo e($dispo->active ? 'success' : 'danger'); ?>">
                                    <?php echo e($dispo->active ? 'Actif' : 'Inactif'); ?>

                                </span>
                            </td>
                            <td>
                                <a href="<?php echo e(route('disponibilites.edit', $dispo->id)); ?>" class="btn btn-sm btn-warning">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                <form action="<?php echo e(route('disponibilites.toggle', $dispo->id)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-sm btn-<?php echo e($dispo->active ? 'secondary' : 'success'); ?>">
                                        <i class="bi bi-<?php echo e($dispo->active ? 'pause' : 'play'); ?>"></i>
                                    </button>
                                </form>
                                <form action="<?php echo e(route('disponibilites.destroy', $dispo->id)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Supprimer ?')">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center">Aucune disponibilité</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cabinet_medical\resources\views/disponibilites/index.blade.php ENDPATH**/ ?>