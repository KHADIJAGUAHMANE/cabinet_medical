

<?php $__env->startSection('title', 'Consultations'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>📋 Consultations médicales</h2>
</div>

<div class="card shadow">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>Patient</th>
                        <th>Médecin</th>
                        <th>Date</th>
                        <th>Diagnostic</th>
                        <th>Ordonnance</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $consultations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($c->patient->user->nom); ?> <?php echo e($c->patient->user->prenom); ?></td>
                        <td>Dr. <?php echo e($c->medecin->nom); ?> <?php echo e($c->medecin->prenom); ?></td>
                        <td><?php echo e($c->date_consultation); ?></td>
                        <td><?php echo e(Str::limit($c->diagnostic, 30) ?? '-'); ?></td>
                        <td>
                            <?php if($c->ordonnance): ?>
                                <span class="badge bg-success">✓</span>
                            <?php else: ?>
                                <span class="badge bg-warning">✗</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(route('consultations.show', $c->id)); ?>" class="btn btn-sm btn-info">Voir</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="6" class="text-center">Aucune consultation</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cabinet_medical\resources\views/consultations/index.blade.php ENDPATH**/ ?>