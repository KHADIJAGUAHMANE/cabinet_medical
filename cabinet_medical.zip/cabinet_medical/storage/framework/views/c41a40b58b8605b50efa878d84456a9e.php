<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion - Cabinet Médical</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="text-center mt-3">
    <p>Pas encore patient ? <a href="<?php echo e(route('register')); ?>">Créez votre compte</a></p>
</div>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-4">
            <div class="card shadow">
                <div class="card-header bg-primary text-white text-center">
                    <h4>Connexion</h4>
                </div>
                <div class="card-body">
                    
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        
                        <?php echo csrf_field(); ?> 

                        <div class="mb-3">
                            <label class="form-label">Adresse Email</label>
                            <input type="email" name="email" class="form-control" placeholder="admin@cabinet.ma" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Mot de passe</label>
                            <input type="password" name="password" class="form-control" placeholder="********" required>
                        </div>

                        <button type="submit" class="btn btn-primary w-100">Se connecter</button>

                    </form>

                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html><?php /**PATH C:\xampp\htdocs\cabinet_medical\resources\views/auth/login.blade.php ENDPATH**/ ?>