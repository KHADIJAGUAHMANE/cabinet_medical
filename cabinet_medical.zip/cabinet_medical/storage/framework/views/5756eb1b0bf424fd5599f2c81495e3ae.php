

<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold">Liste des Patients</h2>

    <a href="<?php echo e(route('patients.create')); ?>" class="btn btn-primary">
        Ajouter un patient
    </a>
</div>

<div class="card shadow border-0 rounded-4">
    <div class="card-body">

        <form method="GET" action="<?php echo e(route('patients.index')); ?>" class="mb-4">
            <div class="row">
                <div class="col-md-10">
                    <input type="text" name="search" class="form-control" placeholder="Rechercher un patient..." value="<?php echo e(request('search')); ?>">
                </div>
                <div class="col-md-2">
                    <button class="btn btn-dark w-100">Rechercher</button>
                </div>
            </div>
        </form>

        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>Nom</th>
                        <th>Prénom</th>
                        <th>Email</th>
                        <th>Téléphone</th>
                        <th>Date naissance</th>
                        <th>Sexe</th>
                        <th>Adresse</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($patient->user->nom); ?></td>
                            <td><?php echo e($patient->user->prenom); ?></td>
                            <td><?php echo e($patient->user->email); ?></td>
                            <td><?php echo e($patient->user->telephone); ?></td>
                            <td><?php echo e($patient->date_naissance); ?></td>
                            <td><?php echo e($patient->sexe); ?></td>
                            <td><?php echo e($patient->adresse); ?></td>
                            <td>
                            <a href="<?php echo e(route('patients.edit', $patient->id)); ?>" class="btn btn-warning btn-sm">Modifier</a>
                            <a href="<?php echo e(route('patients.show', $patient->id)); ?>" class="btn btn-info btn-sm">Voir</a>
                            <form action="<?php echo e(route('patients.destroy', $patient->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Supprimer ce patient ?')">
                            <?php echo csrf_field(); ?>
                             <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm">Supprimer</button>
                        </form>
                        </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-center text-muted">
                                Aucun patient trouvé
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>

            </table>
        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cabinet_medical\resources\views/patients/index.blade.php ENDPATH**/ ?>