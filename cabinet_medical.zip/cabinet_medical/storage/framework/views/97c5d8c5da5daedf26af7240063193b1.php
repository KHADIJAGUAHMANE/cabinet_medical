<!DOCTYPE html>
<html>
<head>
    <title>Utilisateurs</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">

<h2 class="mb-4">Liste des utilisateurs</h2>

<a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary mb-3">Ajouter utilisateur</a>

<table class="table table-bordered table-striped">
    <thead class="table-dark">
        <tr>
            <th>Nom</th>
            <th>Prénom</th>
            <th>Email</th>
            <th>Rôle</th>
            <th>Actions</th>
        </tr>
    </thead>

    <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($user->nom); ?></td>
            <td><?php echo e($user->prenom); ?></td>
            <td><?php echo e($user->email); ?></td>
            <td>
                <span class="badge bg-info"><?php echo e($user->role); ?></span>
            </td>
            <td>
                <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="btn btn-warning btn-sm">Modifier</a>

                <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="POST" style="display:inline;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-danger btn-sm">Supprimer</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

</body>
</html><?php /**PATH C:\xampp\htdocs\cabinet_medical\resources\views/users/index.blade.php ENDPATH**/ ?>