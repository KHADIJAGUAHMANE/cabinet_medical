

<?php $__env->startSection('title', 'Détail consultation'); ?>

<?php $__env->startSection('content'); ?>
<div class="card shadow">
    <div class="card-header bg-white">
        <h5>Consultation du <?php echo e($consultation->date_consultation); ?></h5>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <p><strong>Patient:</strong> <?php echo e($consultation->patient->user->nom); ?> <?php echo e($consultation->patient->user->prenom); ?></p>
                <p><strong>Médecin:</strong> Dr. <?php echo e($consultation->medecin->nom); ?> <?php echo e($consultation->medecin->prenom); ?></p>
            </div>
            <div class="col-md-6">
                <p><strong>Date:</strong> <?php echo e($consultation->date_consultation); ?></p>
                <p><strong>Motif du RDV:</strong> <?php echo e($consultation->rendezVous->motif ?? '-'); ?></p>
            </div>
        </div>
        
        <hr>
        
        <h6>📝 Compte-rendu</h6>
        <p class="border p-3 rounded bg-light"><?php echo e($consultation->compte_rendu); ?></p>
        
        <?php if($consultation->diagnostic): ?>
            <h6>🩺 Diagnostic</h6>
            <p class="border p-3 rounded bg-light"><?php echo e($consultation->diagnostic); ?></p>
        <?php endif; ?>
        
        <?php if($consultation->traitement): ?>
            <h6>💊 Traitement</h6>
            <p class="border p-3 rounded bg-light"><?php echo e($consultation->traitement); ?></p>
        <?php endif; ?>
        
        <hr>
        
        <h6>📋 Ordonnance</h6>
        <?php if($consultation->ordonnance): ?>
            <div class="alert alert-success">
                <strong>Ordonnance n°<?php echo e($consultation->ordonnance->numero_ordonnance); ?></strong><br>
                <strong>Date:</strong> <?php echo e($consultation->ordonnance->date_ordonnance); ?><br>
                <strong>Médicaments:</strong> <?php echo e($consultation->ordonnance->medicaments); ?><br>
                <a href="<?php echo e(route('consultations.ordonnance.pdf', $consultation->ordonnance->id)); ?>" class="btn btn-sm btn-primary mt-2" target="_blank">
                    📄 Télécharger PDF
                </a>
            </div>
        <?php else: ?>
            <div class="alert alert-warning">
                Aucune ordonnance générée.
                <a href="<?php echo e(route('consultations.ordonnance', $consultation->id)); ?>" class="btn btn-sm btn-success ms-2">
                    ➕ Générer ordonnance
                </a>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cabinet_medical\resources\views/consultations/show.blade.php ENDPATH**/ ?>