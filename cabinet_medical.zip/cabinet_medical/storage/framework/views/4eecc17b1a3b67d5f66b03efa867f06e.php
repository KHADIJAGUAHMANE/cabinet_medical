<!DOCTYPE html>
<html>
<head>
    <title>Dashboard - Cabinet Médical</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>

<div class="d-flex">

    <!-- Sidebar -->
    <div class="bg-dark text-white p-3" style="width:250px; min-height:100vh;">
        <h4 class="mb-4">Cabinet Médical</h4>
        <hr>

        <a href="/dashboard" class="text-white text-decoration-none d-block mb-3">
            📊 Dashboard
        </a>

        <a href="/users" class="text-white text-decoration-none d-block mb-3">
            👥 Utilisateurs
        </a>

        <a href="/patients" class="text-white text-decoration-none d-block mb-3">
            🧑 Patients
        </a>

        <a href="/rendezvous" class="text-white text-decoration-none d-block mb-3">
            📅 Rendez-vous
        </a>

        <a href="/disponibilites" class="text-white text-decoration-none d-block mb-3">
            📅 Disponibilités
        </a>

        <a href="/calendrier" class="text-white text-decoration-none d-block mb-3">
            📆 Calendrier
        </a>

        <hr>
        <form action="<?php echo e(route('logout')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-danger w-100">🚪 Déconnexion</button>
        </form>
    </div>

    <!-- Content -->
    <div class="p-4 w-100 bg-light">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\cabinet_medical\resources\views/layouts/admin.blade.php ENDPATH**/ ?>