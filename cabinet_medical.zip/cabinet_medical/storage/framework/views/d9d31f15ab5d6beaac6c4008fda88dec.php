

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Cartes statistiques -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <h5>Total Utilisateurs</h5>
                    <h2><?php echo e($total); ?></h2>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <h5>Patients</h5>
                    <h2><?php echo e($patients); ?></h2>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-warning text-white">
                <div class="card-body">
                    <h5>Médecins</h5>
                    <h2><?php echo e($medecins); ?></h2>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-danger text-white">
                <div class="card-body">
                    <h5>Secrétaires</h5>
                    <h2><?php echo e($secretaires); ?></h2>
                </div>
            </div>
        </div>
    </div>

    <!-- Graphiques -->
    <div class="row mb-4">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header bg-white">
                    <h5>Évolution des rendez-vous (2026)</h5>
                </div>
                <div class="card-body">
                    <canvas id="rdvChart" style="height: 300px; width: 100%;"></canvas>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-header bg-white">
                    <h5>Statut des rendez-vous</h5>
                </div>
                <div class="card-body">
                    <canvas id="statutChart" style="height: 250px; width: 100%;"></canvas>
                    <div class="mt-3 text-center">
                        <span class="badge bg-success">Confirmés: <?php echo e($rdvConfirme); ?></span>
                        <span class="badge bg-warning">En attente: <?php echo e($rdvEnAttente); ?></span>
                        <span class="badge bg-danger">Annulés: <?php echo e($rdvAnnule); ?></span>
                        <span class="badge bg-info">Terminés: <?php echo e($rdvTermine); ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Top Médecins -->
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header bg-white">
                    <h5>Top 5 Médecins</h5>
                </div>
                <div class="card-body">
                    <table class="table table-hover">
                        <thead class="table-dark">
                            <tr>
                                <th>Médecin</th>
                                <th>Spécialité</th>
                                <th>Email</th>
                                <th>RDV</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $topMedecins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $med): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>Dr. <?php echo e($med->nom); ?> <?php echo e($med->prenom); ?></td>
                                <td><?php echo e($med->specialite ?? 'Généraliste'); ?></td>
                                <td><?php echo e($med->email); ?></td>
                                <td><span class="badge bg-primary"><?php echo e($med->rendezvous_count); ?> RDV</span></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
// Attendre que la page soit chargée
document.addEventListener('DOMContentLoaded', function() {
    
    // Graphique évolution
    const ctx = document.getElementById('rdvChart').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: <?php echo json_encode($moisLabels); ?>,
            datasets: [{
                label: 'Nombre de rendez-vous',
                data: <?php echo json_encode($nbRdvParMois); ?>,
                borderColor: '#0d6efd',
                backgroundColor: 'rgba(13, 110, 253, 0.1)',
                borderWidth: 2,
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    position: 'top',
                }
            }
        }
    });

    // Graphique camembert
    const ctx2 = document.getElementById('statutChart').getContext('2d');
    new Chart(ctx2, {
        type: 'pie',
        data: {
            labels: ['Confirmés', 'En attente', 'Annulés', 'Terminés'],
            datasets: [{
                data: [<?php echo e($rdvConfirme); ?>, <?php echo e($rdvEnAttente); ?>, <?php echo e($rdvAnnule); ?>, <?php echo e($rdvTermine); ?>],
                backgroundColor: ['#198754', '#ffc107', '#dc3545', '#0dcaf0'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    position: 'bottom',
                }
            }
        }
    });
    
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cabinet_medical\resources\views/dashboard.blade.php ENDPATH**/ ?>