

<?php $__env->startSection('title', 'Gestion des Rendez-vous'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold">Liste des rendez-vous</h2>
    <div>
        <a href="<?php echo e(route('rendezvous.calendar')); ?>" class="btn btn-info">
            <i class="bi bi-calendar"></i> Voir calendrier
        </a>
        <a href="<?php echo e(route('rendezvous.create')); ?>" class="btn btn-success">
            <i class="bi bi-plus-circle"></i> Ajouter un rendez-vous
        </a>
    </div>
</div>

<div class="card shadow border-0 rounded-4">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>Patient</th>
                        <th>Médecin</th>
                        <th>Date</th>
                        <th>Heure</th>
                        <th>Statut</th>
                        <th>Motif</th>
                        <th>Actions</th>
                        <th>Consultation</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $rendezvous; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rdv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($rdv->patient->user->nom); ?> <?php echo e($rdv->patient->user->prenom); ?></td>
                        <td>Dr. <?php echo e($rdv->medecin->nom); ?> <?php echo e($rdv->medecin->prenom); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($rdv->date_heure)->format('d/m/Y')); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($rdv->date_heure)->format('H:i')); ?></td>
                        <td>
                            <select class="form-select form-select-sm statut-select" data-id="<?php echo e($rdv->id); ?>" style="width: 120px;">
                                <option value="en_attente" <?php echo e($rdv->statut == 'en_attente' ? 'selected' : ''); ?>>En attente</option>
                                <option value="confirme" <?php echo e($rdv->statut == 'confirme' ? 'selected' : ''); ?>>Confirmé</option>
                                <option value="termine" <?php echo e($rdv->statut == 'termine' ? 'selected' : ''); ?>>Terminé</option>
                                <option value="annule" <?php echo e($rdv->statut == 'annule' ? 'selected' : ''); ?>>Annulé</option>
                            </select>
                        </td>
                        <td><?php echo e($rdv->motif ?? '-'); ?></td>
                        <td>
                            <a href="<?php echo e(route('rendezvous.edit', $rdv->id)); ?>" class="btn btn-warning btn-sm">Modifier</a>
                            <form action="<?php echo e(route('rendezvous.destroy', $rdv->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Supprimer ce rendez-vous ?')">Supprimer</button>
                            </form>
                        </td>
                        <td>
                            <?php if($rdv->statut == 'termine'): ?>
                                <?php if($rdv->consultation): ?>
                                    <a href="<?php echo e(route('consultations.show', $rdv->consultation->id)); ?>" class="btn btn-sm btn-info">Voir consultation</a>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Aucune</span>
                                <?php endif; ?>
                            <?php elseif($rdv->statut == 'confirme'): ?>
                                <a href="<?php echo e(route('consultations.create', $rdv->id)); ?>" class="btn btn-sm btn-success">Ajouter consultation</a>
                            <?php else: ?>
                                <span class="badge bg-secondary">-</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-center text-muted py-4">
                                Aucun rendez-vous trouvé.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.querySelectorAll('.statut-select').forEach(select => {
        select.addEventListener('change', function() {
            const id = this.dataset.id;
            const statut = this.value;
            
            fetch(`/rendezvous/${id}/statut`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                },
                body: JSON.stringify({ statut: statut })
            })
            .then(response => response.json())
            .then(data => {
                if(data.success) {
                    location.reload();
                }
            });
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cabinet_medical\resources\views/rendezvous/index.blade.php ENDPATH**/ ?>