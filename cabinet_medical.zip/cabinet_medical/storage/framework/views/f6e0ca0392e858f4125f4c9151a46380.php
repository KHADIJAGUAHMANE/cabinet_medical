

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold">Détails du Patient</h2>
    <div>
        <a href="<?php echo e(route('patients.edit', $patient->id)); ?>" class="btn btn-warning">Modifier</a>
        <a href="<?php echo e(route('patients.index')); ?>" class="btn btn-secondary">Retour</a>
    </div>
</div>
<a href="<?php echo e(route('patients.historique', $patient->id)); ?>" class="btn btn-info mt-3">
    <i class="bi bi-clock-history"></i> Voir historique médical
</a>
<div class="card shadow border-0 rounded-4">
    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <table class="table table-bordered">
                    <tr>
                        <th width="40%">Nom complet</th>
                        <td><?php echo e($patient->user->nom); ?> <?php echo e($patient->user->prenom); ?></td>
                    </tr>
                    <tr>
                        <th>Email</th>
                        <td><?php echo e($patient->user->email); ?></td>
                    </tr>
                    <tr>
                        <th>Téléphone</th>
                        <td><?php echo e($patient->user->telephone ?? 'Non renseigné'); ?></td>
                    </tr>
                    <tr>
                        <th>Date de naissance</th>
                        <td><?php echo e($patient->date_naissance ?? 'Non renseignée'); ?></td>
                    </tr>
                    <tr>
                        <th>Sexe</th>
                        <td><?php echo e($patient->sexe == 'M' ? 'Masculin' : 'Féminin'); ?></td>
                    </tr>
                    <tr>
                        <th>Adresse</th>
                        <td><?php echo e($patient->adresse ?? 'Non renseignée'); ?></td>
                    </tr>
                    <tr>
                        <th>Date d'inscription</th>
                        <td><?php echo e($patient->created_at->format('d/m/Y H:i')); ?></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</div>

<?php if(isset($patient->rendezvous) && $patient->rendezvous->count() > 0): ?>
<div class="card shadow border-0 rounded-4 mt-4">
    <div class="card-header bg-dark text-white">
        <h5 class="mb-0">Historique des rendez-vous</h5>
    </div>
    <div class="card-body">
        <table class="table">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Heure</th>
                    <th>Statut</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $patient->rendezvous; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rdv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($rdv->date); ?></td>
                    <td><?php echo e($rdv->heure); ?></td>
                    <td>
                        <span class="badge bg-<?php echo e($rdv->statut == 'confirme' ? 'success' : 'warning'); ?>">
                            <?php echo e($rdv->statut); ?>

                        </span>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cabinet_medical\resources\views/patients/show.blade.php ENDPATH**/ ?>