

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold">Modifier un Patient</h2>
    <a href="<?php echo e(route('patients.index')); ?>" class="btn btn-secondary">Retour à la liste</a>
</div>

<div class="card shadow border-0 rounded-4">
    <div class="card-body">
        <form action="<?php echo e(route('patients.update', $patient->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="nom" class="form-label">Nom</label>
                    <input type="text" name="nom" class="form-control" value="<?php echo e(old('nom', $patient->user->nom)); ?>" required>
                </div>

                <div class="col-md-6 mb-3">
                    <label for="prenom" class="form-label">Prénom</label>
                    <input type="text" name="prenom" class="form-control" value="<?php echo e(old('prenom', $patient->user->prenom)); ?>" required>
                </div>

                <div class="col-md-6 mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" name="email" class="form-control" value="<?php echo e(old('email', $patient->user->email)); ?>" required>
                </div>

                <div class="col-md-6 mb-3">
                    <label for="telephone" class="form-label">Téléphone</label>
                    <input type="text" name="telephone" class="form-control" value="<?php echo e(old('telephone', $patient->user->telephone)); ?>">
                </div>

                <div class="col-md-6 mb-3">
                    <label for="date_naissance" class="form-label">Date de naissance</label>
                    <input type="date" name="date_naissance" class="form-control" value="<?php echo e(old('date_naissance', $patient->date_naissance)); ?>">
                </div>

                <div class="col-md-6 mb-3">
                    <label for="sexe" class="form-label">Sexe</label>
                    <select name="sexe" class="form-control">
                        <option value="M" <?php echo e($patient->sexe == 'M' ? 'selected' : ''); ?>>Masculin</option>
                        <option value="F" <?php echo e($patient->sexe == 'F' ? 'selected' : ''); ?>>Féminin</option>
                    </select>
                </div>

                <div class="col-md-12 mb-3">
                    <label for="adresse" class="form-label">Adresse</label>
                    <textarea name="adresse" class="form-control" rows="2"><?php echo e(old('adresse', $patient->adresse)); ?></textarea>
                </div>
            </div>

            <div class="text-end">
                <button type="submit" class="btn btn-primary">Mettre à jour</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cabinet_medical\resources\views/patients/edit.blade.php ENDPATH**/ ?>