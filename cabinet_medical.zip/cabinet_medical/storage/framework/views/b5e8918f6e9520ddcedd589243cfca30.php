

<?php $__env->startSection('title', 'Modifier un rendez-vous'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold">Modifier un rendez-vous</h2>
    <a href="<?php echo e(route('rendezvous.index')); ?>" class="btn btn-secondary">Retour à la liste</a>
</div>

<div class="card shadow border-0 rounded-4">
    <div class="card-body">
        <form action="<?php echo e(route('rendezvous.update', $rdv->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="patient_id" class="form-label">Patient</label>
                    <select name="patient_id" id="patient_id" class="form-control" required>
                        <option value="">Sélectionner un patient</option>
                        <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($patient->id); ?>" <?php echo e($rdv->patient_id == $patient->id ? 'selected' : ''); ?>>
                                <?php echo e($patient->user->nom); ?> <?php echo e($patient->user->prenom); ?> - <?php echo e($patient->user->email); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="col-md-6 mb-3">
                    <label for="medecin_id" class="form-label">Médecin</label>
                    <<select name="user_id_medecin" id="user_id_medecin" class="form-control" required>
    <option value="">Sélectionner un médecin</option>
    <?php $__currentLoopData = $medecins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medecin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($medecin->id); ?>" <?php echo e($rdv->user_id_medecin == $medecin->id ? 'selected' : ''); ?>>
            Dr. <?php echo e($medecin->nom); ?> <?php echo e($medecin->prenom); ?>

        </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
                </div>

                <div class="col-md-4 mb-3">
                    <label for="date" class="form-label">Date</label>
                    <input type="date" name="date" id="date" class="form-control" value="<?php echo e($rdv->date); ?>" required>
                </div>

                <div class="col-md-4 mb-3">
                    <label for="heure" class="form-label">Heure</label>
                    <input type="time" name="heure" id="heure" class="form-control" value="<?php echo e($rdv->heure); ?>" required>
                </div>

                <div class="col-md-4 mb-3">
                    <label for="statut" class="form-label">Statut</label>
                    <select name="statut" id="statut" class="form-control" required>
                        <option value="en_attente" <?php echo e($rdv->statut == 'en_attente' ? 'selected' : ''); ?>>En attente</option>
                        <option value="confirme" <?php echo e($rdv->statut == 'confirme' ? 'selected' : ''); ?>>Confirmé</option>
                        <option value="termine" <?php echo e($rdv->statut == 'termine' ? 'selected' : ''); ?>>Terminé</option>
                        <option value="annule" <?php echo e($rdv->statut == 'annule' ? 'selected' : ''); ?>>Annulé</option>
                    </select>
                </div>

                <div class="col-md-12 mb-3">
                    <label for="motif" class="form-label">Motif</label>
                    <textarea name="motif" id="motif" class="form-control" rows="3"><?php echo e($rdv->motif); ?></textarea>
                </div>
            </div>

            <div class="text-end">
                <button type="submit" class="btn btn-primary">Mettre à jour</button>
                <a href="<?php echo e(route('rendezvous.index')); ?>" class="btn btn-secondary">Annuler</a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cabinet_medical\resources\views/rendezvous/edit.blade.php ENDPATH**/ ?>