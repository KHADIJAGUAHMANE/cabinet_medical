<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirmation de rendez-vous</title>
    <style>
        body {
            font-family: Arial, Helvetica, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #ffffff;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .header {
            background: linear-gradient(135deg, #1e3c72, #2a5298);
            color: white;
            padding: 30px;
            text-align: center;
        }
        .header h1 {
            margin: 0;
            font-size: 24px;
        }
        .content {
            padding: 30px;
        }
        .info-card {
            background-color: #f8f9fc;
            border-left: 4px solid #2a5298;
            padding: 15px;
            margin: 20px 0;
            border-radius: 5px;
        }
        .info-card p {
            margin: 8px 0;
        }
        .label {
            font-weight: bold;
            color: #1e3c72;
            width: 120px;
            display: inline-block;
        }
        .status {
            display: inline-block;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
        }
        .status-en-attente {
            background-color: #ffc107;
            color: #000;
        }
        .status-confirme {
            background-color: #198754;
            color: white;
        }
        .footer {
            background-color: #f4f4f4;
            padding: 20px;
            text-align: center;
            font-size: 12px;
            color: #666;
        }
        .btn {
            display: inline-block;
            padding: 10px 25px;
            background-color: #2a5298;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 20px;
        }
        .btn:hover {
            background-color: #1e3c72;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🏥 Cabinet Médical</h1>
            <p>Confirmation de rendez-vous</p>
        </div>

        <div class="content">
            <h2>Bonjour {{ $rendezvous->patient->user->nom ?? 'Patient' }} {{ $rendezvous->patient->user->prenom ?? '' }},</h2>
            
            <p>Nous vous confirmons votre rendez-vous au Cabinet Médical.</p>

            <div class="info-card">
                <p>
                    <span class="label">📅 Date :</span> 
                    {{ \Carbon\Carbon::parse($rendezvous->date)->format('d/m/Y') }}
                </p>
                <p>
                    <span class="label">⏰ Heure :</span> 
                    {{ $rendezvous->heure }}
                </p>
                <p>
                    <span class="label">👨‍⚕️ Médecin :</span> 
                    Dr. {{ $rendezvous->medecin->nom ?? '' }} {{ $rendezvous->medecin->prenom ?? '' }}
                </p>
                <p>
                    <span class="label">📍 Statut :</span> 
                    <span class="status status-{{ $rendezvous->statut }}">
                        {{ $rendezvous->statut == 'en_attente' ? 'En attente de confirmation' : ucfirst($rendezvous->statut) }}
                    </span>
                </p>
                @if($rendezvous->motif)
                <p>
                    <span class="label">📝 Motif :</span> 
                    {{ $rendezvous->motif }}
                </p>
                @endif
            </div>

            <p><strong>Informations pratiques :</strong></p>
            <ul>
                <li>Merci d'arriver 10 minutes avant votre rendez-vous</li>
                <li>Munissez-vous de votre carte d'identité et carte vitale</li>
                <li>En cas d'empêchement, merci d'annuler au moins 24h à l'avance</li>
            </ul>

            <center>
                <a href="{{ url('/dashboard') }}" class="btn">Accéder à mon espace</a>
            </center>
        </div>

        <div class="footer">
            <p>Cabinet Médical - Tous droits réservés</p>
            <p>Cet email est généré automatiquement, merci de ne pas y répondre.</p>
        </div>
    </div>
</body>
</html>

