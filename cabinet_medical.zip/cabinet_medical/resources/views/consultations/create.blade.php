@extends('layouts.admin')

@section('title', 'Nouvelle consultation')

@section('content')
<div class="card shadow">
    <div class="card-header bg-white">
        <h5>Consultation - {{ $rdv->patient->user->nom }} {{ $rdv->patient->user->prenom }}</h5>
        <p>Médecin: Dr. {{ $rdv->medecin->nom }} {{ $rdv->medecin->prenom }}</p>
        <p>Date RDV: {{ \Carbon\Carbon::parse($rdv->date_heure)->format('d/m/Y H:i') }}</p>
    </div>
    <div class="card-body">
        <form action="{{ route('consultations.store') }}" method="POST">
            @csrf
            <input type="hidden" name="rendez_vous_id" value="{{ $rdv->id }}">

            <div class="mb-3">
                <label class="form-label">📝 Compte-rendu</label>
                <textarea name="compte_rendu" class="form-control" rows="5" required placeholder="Détail de la consultation..."></textarea>
            </div>

            <div class="mb-3">
                <label class="form-label">🩺 Diagnostic</label>
                <textarea name="diagnostic" class="form-control" rows="3" placeholder="Diagnostic établi..."></textarea>
            </div>

            <div class="mb-3">
                <label class="form-label">💊 Traitement</label>
                <textarea name="traitement" class="form-control" rows="3" placeholder="Traitement prescrit..."></textarea>
            </div>

            <button type="submit" class="btn btn-primary">Enregistrer la consultation</button>
            <a href="{{ route('rendezvous.index') }}" class="btn btn-secondary">Annuler</a>
        </form>
    </div>
</div>
@endsection