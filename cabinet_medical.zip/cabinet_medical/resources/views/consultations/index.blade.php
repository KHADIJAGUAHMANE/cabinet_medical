@extends('layouts.admin')

@section('title', 'Consultations')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>📋 Consultations médicales</h2>
</div>

<div class="card shadow">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>Patient</th>
                        <th>Médecin</th>
                        <th>Date</th>
                        <th>Diagnostic</th>
                        <th>Ordonnance</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($consultations as $c)
                    <tr>
                        <td>{{ $c->patient->user->nom }} {{ $c->patient->user->prenom }}</td>
                        <td>Dr. {{ $c->medecin->nom }} {{ $c->medecin->prenom }}</td>
                        <td>{{ $c->date_consultation }}</td>
                        <td>{{ Str::limit($c->diagnostic, 30) ?? '-' }}</td>
                        <td>
                            @if($c->ordonnance)
                                <span class="badge bg-success">✓</span>
                            @else
                                <span class="badge bg-warning">✗</span>
                            @endif
                        </td>
                        <td>
                            <a href="{{ route('consultations.show', $c->id) }}" class="btn btn-sm btn-info">Voir</a>
                        </td>
                    </tr>
                    @empty
                        <tr><td colspan="6" class="text-center">Aucune consultation</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection
