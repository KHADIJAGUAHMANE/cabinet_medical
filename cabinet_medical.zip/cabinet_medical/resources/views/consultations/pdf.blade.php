<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Ordonnance médicale</title>
    <style>
        body {
            font-family: 'DejaVu Sans', 'Arial', sans-serif;
            margin: 50px;
            background: white;
        }
        @media print {
            body { margin: 0; padding: 20px; }
            .no-print { display: none; }
            button { display: none; }
        }
        .header {
            text-align: center;
            border-bottom: 2px solid #1e3c72;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }
        .header h1 {
            margin: 0;
            color: #1e3c72;
        }
        .header p {
            margin: 5px 0;
            color: #666;
        }
        .info {
            margin-bottom: 30px;
            padding: 10px;
            background: #f5f5f5;
        }
        .info table {
            width: 100%;
        }
        .info td {
            padding: 5px;
        }
        .medicaments {
            margin: 20px 0;
            padding: 15px;
            border-left: 4px solid #1e3c72;
            background: #f9f9f9;
        }
        .medicaments h3 {
            color: #1e3c72;
            margin-top: 0;
        }
        .signature {
            margin-top: 50px;
            text-align: right;
            border-top: 1px solid #ccc;
            padding-top: 20px;
        }
        .footer {
            margin-top: 50px;
            text-align: center;
            font-size: 11px;
            color: #999;
        }
        .numero {
            font-size: 12px;
            text-align: right;
            margin-bottom: 20px;
        }
        button {
            background: #1e3c72;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            margin-bottom: 20px;
        }
        button:hover {
            background: #2a5298;
        }
    </style>
</head>
<body>

<button onclick="window.print()" class="no-print" style="margin-bottom:20px;">
    🖨️ Imprimer / Enregistrer PDF
</button>

<div class="numero">
    <strong>N° Ordonnance:</strong> {{ $ordonnance->numero_ordonnance }}
</div>

<div class="header">
    <h1>🏥 Cabinet Médical</h1>
    <p>123 Rue de la Liberté, Casablanca</p>
    <p>Tél: 05 XX XX XX XX | Email: cabinet@medical.ma</p>
</div>

<div class="info">
    <table>
        <tr>
            <td width="50%"><strong>Patient :</strong> {{ $ordonnance->patient->user->nom }} {{ $ordonnance->patient->user->prenom }}</td>
            <td width="50%"><strong>Date :</strong> {{ \Carbon\Carbon::parse($ordonnance->date_ordonnance)->format('d/m/Y') }}</td>
        </tr>
        <tr>
            <td><strong>Médecin :</strong> Dr. {{ $ordonnance->consultation->medecin->nom }} {{ $ordonnance->consultation->medecin->prenom }}</td>
            <td><strong>Spécialité :</strong> {{ $ordonnance->consultation->medecin->specialite ?? 'Généraliste' }}</td>
        </tr>
    </table>
</div>

<div class="medicaments">
    <h3>💊 Médicaments prescrits :</h3>
    {!! nl2br(e($ordonnance->medicaments)) !!}
</div>

@if($ordonnance->posologies)
<div style="margin: 20px 0;">
    <h3>⏰ Posologies :</h3>
    {!! nl2br(e($ordonnance->posologies)) !!}
</div>
@endif

@if($ordonnance->recommandations)
<div style="margin: 20px 0;">
    <h3>📝 Recommandations :</h3>
    {!! nl2br(e($ordonnance->recommandations)) !!}
</div>
@endif

<div class="signature">
    <p>Le médecin,</p>
    <p style="margin-top: 30px;"><strong>Dr. {{ $ordonnance->consultation->medecin->nom }} {{ $ordonnance->consultation->medecin->prenom }}</strong></p>
    <p><em>Signature électronique</em></p>
</div>

<div class="footer">
    <p>Cette ordonnance est valable pendant 3 mois.</p>
    <p>Cabinet Médical - Tous droits réservés</p>
</div>

<script>
    // Auto-print if needed
    // window.onload = function() { window.print(); }
</script>
</body>
</html>