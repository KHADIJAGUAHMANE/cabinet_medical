@extends('layouts.admin')

@section('title', 'Générer ordonnance')

@section('content')
<div class="card shadow">
    <div class="card-header bg-white">
        <h5>Générer ordonnance pour {{ $consultation->patient->user->nom }} {{ $consultation->patient->user->prenom }}</h5>
        <p>Médecin: Dr. {{ $consultation->medecin->nom }} {{ $consultation->medecin->prenom }}</p>
    </div>
    <div class="card-body">
        <form action="{{ route('consultations.ordonnance.store', $consultation->id) }}" method="POST">
            @csrf

            <div class="mb-3">
                <label class="form-label">💊 Médicaments prescrits</label>
                <textarea name="medicaments" class="form-control" rows="5" required 
                    placeholder="Paracétamol 500mg&#10;Amoxicilline 250mg&#10;Vitamine C 1000mg"></textarea>
                <small class="text-muted">Un médicament par ligne</small>
            </div>

            <div class="mb-3">
                <label class="form-label">⏰ Posologies</label>
                <textarea name="posologies" class="form-control" rows="3" 
                    placeholder="Matin, midi et soir&#10;1 comprimé 3 fois par jour"></textarea>
            </div>

            <div class="mb-3">
                <label class="form-label">📝 Recommandations</label>
                <textarea name="recommandations" class="form-control" rows="3" 
                    placeholder="Repos pendant 3 jours&#10;Boire beaucoup d'eau"></textarea>
            </div>

            <button type="submit" class="btn btn-primary">Générer l'ordonnance</button>
            <a href="{{ route('consultations.show', $consultation->id) }}" class="btn btn-secondary">Annuler</a>
        </form>
    </div>
</div>
@endsection