@extends('layouts.admin')

@section('title', 'Détail consultation')

@section('content')
<div class="card shadow">
    <div class="card-header bg-white">
        <h5>Consultation du {{ $consultation->date_consultation }}</h5>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <p><strong>Patient:</strong> {{ $consultation->patient->user->nom }} {{ $consultation->patient->user->prenom }}</p>
                <p><strong>Médecin:</strong> Dr. {{ $consultation->medecin->nom }} {{ $consultation->medecin->prenom }}</p>
            </div>
            <div class="col-md-6">
                <p><strong>Date:</strong> {{ $consultation->date_consultation }}</p>
                <p><strong>Motif du RDV:</strong> {{ $consultation->rendezVous->motif ?? '-' }}</p>
            </div>
        </div>
        
        <hr>
        
        <h6>📝 Compte-rendu</h6>
        <p class="border p-3 rounded bg-light">{{ $consultation->compte_rendu }}</p>
        
        @if($consultation->diagnostic)
            <h6>🩺 Diagnostic</h6>
            <p class="border p-3 rounded bg-light">{{ $consultation->diagnostic }}</p>
        @endif
        
        @if($consultation->traitement)
            <h6>💊 Traitement</h6>
            <p class="border p-3 rounded bg-light">{{ $consultation->traitement }}</p>
        @endif
        
        <hr>
        
        <h6>📋 Ordonnance</h6>
        @if($consultation->ordonnance)
            <div class="alert alert-success">
                <strong>Ordonnance n°{{ $consultation->ordonnance->numero_ordonnance }}</strong><br>
                <strong>Date:</strong> {{ $consultation->ordonnance->date_ordonnance }}<br>
                <strong>Médicaments:</strong> {{ $consultation->ordonnance->medicaments }}<br>
                <a href="{{ route('consultations.ordonnance.pdf', $consultation->ordonnance->id) }}" class="btn btn-sm btn-primary mt-2" target="_blank">
                    📄 Télécharger PDF
                </a>
            </div>
        @else
            <div class="alert alert-warning">
                Aucune ordonnance générée.
                <a href="{{ route('consultations.ordonnance', $consultation->id) }}" class="btn btn-sm btn-success ms-2">
                    ➕ Générer ordonnance
                </a>
            </div>
        @endif
    </div>
</div>
@endsection