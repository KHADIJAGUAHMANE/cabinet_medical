<h2>Ajouter utilisateur</h2>

<form method="POST" action="{{ route('users.store') }}">
    @csrf

    <input type="text" name="nom" placeholder="Nom">
    <input type="text" name="prenom" placeholder="Prénom">
    <input type="email" name="email" placeholder="Email">
    <input type="password" name="password" placeholder="Mot de passe">

    <select name="role">
        <option value="admin">Admin</option>
        <option value="medecin">Médecin</option>
        <option value="secretaire">Secrétaire</option>
        <option value="patient">Patient</option>
    </select>

    <input type="text" name="telephone" placeholder="Téléphone">

    <button type="submit">Ajouter</button>
</form>