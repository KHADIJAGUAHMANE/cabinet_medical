<!DOCTYPE html>
<html>
<head>
    <title>Utilisateurs</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">

<h2 class="mb-4">Liste des utilisateurs</h2>

<a href="{{ route('users.create') }}" class="btn btn-primary mb-3">Ajouter utilisateur</a>

<table class="table table-hover align-middle">
    <thead class="table-dark">
        <tr>
            <th>Patient</th>
            <th>Médecin</th>
            <th>Date</th>
            <th>Heure</th>
            <th>Statut</th>
            <th>Motif</th>
            <th>Actions</th>
            <th>Consultation</th>  ← NOUVEAU
        </tr>
    </thead>
    <tbody>
        @forelse($rendezvous as $rdv)
        <tr>
            <td>{{ $rdv->patient->user->nom }} {{ $rdv->patient->user->prenom }}</td>
            <td>Dr. {{ $rdv->medecin->nom }} {{ $rdv->medecin->prenom }}</td>
            <td>{{ \Carbon\Carbon::parse($rdv->date_heure)->format('d/m/Y') }}</td>
            <td>{{ \Carbon\Carbon::parse($rdv->date_heure)->format('H:i') }}</td>
            <td>
                <select class="form-select form-select-sm statut-select" data-id="{{ $rdv->id }}">
                    <option value="en_attente" {{ $rdv->statut == 'en_attente' ? 'selected' : '' }}>En attente</option>
                    <option value="confirme" {{ $rdv->statut == 'confirme' ? 'selected' : '' }}>Confirmé</option>
                    <option value="termine" {{ $rdv->statut == 'termine' ? 'selected' : '' }}>Terminé</option>
                    <option value="annule" {{ $rdv->statut == 'annule' ? 'selected' : '' }}>Annulé</option>
                </select>
            </td>
            <td>{{ $rdv->motif ?? '-' }}</td>
            <td>
                <a href="{{ route('rendezvous.edit', $rdv->id) }}" class="btn btn-warning btn-sm">Modifier</a>
                <form action="{{ route('rendezvous.destroy', $rdv->id) }}" method="POST" class="d-inline">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn btn-danger btn-sm">Supprimer</button>
                </form>
            </td>
            <td>  ← NOUVEAU
                @if($rdv->statut == 'termine')
                    @if($rdv->consultation)
                        <a href="{{ route('consultations.show', $rdv->consultation->id) }}" class="btn btn-sm btn-info">
                            Voir consultation
                        </a>
                    @else
                        <span class="badge bg-secondary">Aucune</span>
                    @endif
                @elseif($rdv->statut == 'confirme')
                    <a href="{{ route('consultations.create', $rdv->id) }}" class="btn btn-sm btn-success">
                        Ajouter consultation
                    </a>
                @else
                    <span class="badge bg-secondary">Non dispo</span>
                @endif
            </td>
        </tr>
        @empty
        <tr>
            <td colspan="8" class="text-center">Aucun rendez-vous</td>
        </tr>
        @endforelse
    </tbody>
</table>
</body>
</html>