<h2>Modifier utilisateur</h2>

<form method="POST" action="{{ route('users.update', $user->id) }}">
    @csrf
    @method('PUT')

    <input type="text" name="nom" value="{{ $user->nom }}">
    <input type="text" name="prenom" value="{{ $user->prenom }}">
    <input type="email" name="email" value="{{ $user->email }}">

    <select name="role">
        <option value="admin" {{ $user->role=='admin'?'selected':'' }}>Admin</option>
        <option value="medecin" {{ $user->role=='medecin'?'selected':'' }}>Médecin</option>
        <option value="secretaire" {{ $user->role=='secretaire'?'selected':'' }}>Secrétaire</option>
        <option value="patient" {{ $user->role=='patient'?'selected':'' }}>Patient</option>
    </select>

    <input type="text" name="telephone" value="{{ $user->telephone }}">

    <button type="submit">Modifier</button>
</form>