@extends('layouts.admin')

@section('title', 'Calendrier des rendez-vous')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold">Calendrier des rendez-vous</h2>
    <div>
        <a href="{{ route('rendezvous.index') }}" class="btn btn-secondary">
            <i class="bi bi-list"></i> Liste des rendez-vous
        </a>
        <a href="{{ route('rendezvous.create') }}" class="btn btn-primary">
            <i class="bi bi-plus-circle"></i> Nouveau rendez-vous
        </a>
    </div>
</div>

<div class="card shadow border-0 rounded-4">
    <div class="card-body">
        <div id="calendar"></div>
    </div>
</div>
@endsection

@push('styles')
<link href="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.css" rel="stylesheet">
<style>
    .fc-event-title {
        font-weight: bold;
    }
    .fc-day-grid-event .fc-content {
        white-space: normal;
    }
</style>
@endpush

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/locales/fr.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        var calendarEl = document.getElementById('calendar');
        var calendar = new FullCalendar.Calendar(calendarEl, {
            locale: 'fr',
            initialView: 'dayGridMonth',
            headerToolbar: {
                left: 'prev,next today',
                center: 'title',
                right: 'dayGridMonth,timeGridWeek,timeGridDay'
            },
            events: {!! json_encode($events) !!},
            eventClick: function(info) {
                // Rediriger vers l'édition du rendez-vous (si vous avez l'ID dans l'événement)
                if (info.event.id) {
                    window.location.href = '/rendezvous/' + info.event.id + '/edit';
                }
            },
            height: 600,
            buttonText: {
                today: 'Aujourd\'hui',
                month: 'Mois',
                week: 'Semaine',
                day: 'Jour'
            }
        });
        calendar.render();
    });
</script>
@endpush