@extends('layouts.admin')

@section('title', 'Ajouter un rendez-vous')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold">Ajouter un rendez-vous</h2>
    <a href="{{ route('rendezvous.index') }}" class="btn btn-secondary">Retour à la liste</a>
</div>

<div class="card shadow border-0 rounded-4">
    <div class="card-body">
        <form action="{{ route('rendezvous.store') }}" method="POST">
            @csrf

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="patient_id" class="form-label">Patient</label>
                    <select name="patient_id" id="patient_id" class="form-control" required>
                        <option value="">Sélectionner un patient</option>
                        @foreach($patients as $patient)
                            <option value="{{ $patient->id }}">
                                {{ $patient->user->nom }} {{ $patient->user->prenom }} - {{ $patient->user->email }}
                            </option>
                        @endforeach
                    </select>
                </div>

                <div class="col-md-6 mb-3">
                    <label for="medecin_id" class="form-label">Médecin</label>
                    <select name="user_id_medecin" id="user_id_medecin" class="form-control" required>
                        <option value="">Sélectionner un médecin</option>
                        @foreach($medecins as $medecin)
                        <option value="{{ $medecin->id }}">
                        Dr. {{ $medecin->nom }} {{ $medecin->prenom }}
                        </option>
                        @endforeach
                    </select>
                </div>

                <div class="col-md-6 mb-3">
                    <label for="date" class="form-label">Date</label>
                    <input type="date" name="date" id="date" class="form-control" required>
                </div>

                <div class="col-md-6 mb-3">
                    <label for="heure" class="form-label">Heure</label>
                    <input type="time" name="heure" id="heure" class="form-control" required>
                </div>

                <div class="col-md-12 mb-3">
                    <label for="motif" class="form-label">Motif de la consultation</label>
                    <textarea name="motif" id="motif" class="form-control" rows="3" placeholder="Motif de la consultation..."></textarea>
                </div>
            </div>

            <div class="text-end">
                <button type="submit" class="btn btn-primary">Enregistrer</button>
                <a href="{{ route('rendezvous.index') }}" class="btn btn-secondary">Annuler</a>
            </div>
        </form>
    </div>
</div>
@endsection




