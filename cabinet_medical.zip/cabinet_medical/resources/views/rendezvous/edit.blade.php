@extends('layouts.admin')

@section('title', 'Modifier un rendez-vous')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold">Modifier un rendez-vous</h2>
    <a href="{{ route('rendezvous.index') }}" class="btn btn-secondary">Retour à la liste</a>
</div>

<div class="card shadow border-0 rounded-4">
    <div class="card-body">
        <form action="{{ route('rendezvous.update', $rdv->id) }}" method="POST">
            @csrf
            @method('PUT')

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="patient_id" class="form-label">Patient</label>
                    <select name="patient_id" id="patient_id" class="form-control" required>
                        <option value="">Sélectionner un patient</option>
                        @foreach($patients as $patient)
                            <option value="{{ $patient->id }}" {{ $rdv->patient_id == $patient->id ? 'selected' : '' }}>
                                {{ $patient->user->nom }} {{ $patient->user->prenom }} - {{ $patient->user->email }}
                            </option>
                        @endforeach
                    </select>
                </div>

                <div class="col-md-6 mb-3">
                    <label for="medecin_id" class="form-label">Médecin</label>
                    <<select name="user_id_medecin" id="user_id_medecin" class="form-control" required>
    <option value="">Sélectionner un médecin</option>
    @foreach($medecins as $medecin)
        <option value="{{ $medecin->id }}" {{ $rdv->user_id_medecin == $medecin->id ? 'selected' : '' }}>
            Dr. {{ $medecin->nom }} {{ $medecin->prenom }}
        </option>
    @endforeach
</select>
                </div>

                <div class="col-md-4 mb-3">
                    <label for="date" class="form-label">Date</label>
                    <input type="date" name="date" id="date" class="form-control" value="{{ $rdv->date }}" required>
                </div>

                <div class="col-md-4 mb-3">
                    <label for="heure" class="form-label">Heure</label>
                    <input type="time" name="heure" id="heure" class="form-control" value="{{ $rdv->heure }}" required>
                </div>

                <div class="col-md-4 mb-3">
                    <label for="statut" class="form-label">Statut</label>
                    <select name="statut" id="statut" class="form-control" required>
                        <option value="en_attente" {{ $rdv->statut == 'en_attente' ? 'selected' : '' }}>En attente</option>
                        <option value="confirme" {{ $rdv->statut == 'confirme' ? 'selected' : '' }}>Confirmé</option>
                        <option value="termine" {{ $rdv->statut == 'termine' ? 'selected' : '' }}>Terminé</option>
                        <option value="annule" {{ $rdv->statut == 'annule' ? 'selected' : '' }}>Annulé</option>
                    </select>
                </div>

                <div class="col-md-12 mb-3">
                    <label for="motif" class="form-label">Motif</label>
                    <textarea name="motif" id="motif" class="form-control" rows="3">{{ $rdv->motif }}</textarea>
                </div>
            </div>

            <div class="text-end">
                <button type="submit" class="btn btn-primary">Mettre à jour</button>
                <a href="{{ route('rendezvous.index') }}" class="btn btn-secondary">Annuler</a>
            </div>
        </form>
    </div>
</div>
@endsection