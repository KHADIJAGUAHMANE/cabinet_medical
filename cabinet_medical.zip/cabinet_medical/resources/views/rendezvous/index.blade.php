@extends('layouts.admin')

@section('title', 'Gestion des Rendez-vous')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold">Liste des rendez-vous</h2>
    <div>
        <a href="{{ route('rendezvous.calendar') }}" class="btn btn-info">
            <i class="bi bi-calendar"></i> Voir calendrier
        </a>
        <a href="{{ route('rendezvous.create') }}" class="btn btn-success">
            <i class="bi bi-plus-circle"></i> Ajouter un rendez-vous
        </a>
    </div>
</div>

<div class="card shadow border-0 rounded-4">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>Patient</th>
                        <th>Médecin</th>
                        <th>Date</th>
                        <th>Heure</th>
                        <th>Statut</th>
                        <th>Motif</th>
                        <th>Actions</th>
                        <th>Consultation</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($rendezvous as $rdv)
                    <tr>
                        <td>{{ $rdv->patient->user->nom }} {{ $rdv->patient->user->prenom }}</td>
                        <td>Dr. {{ $rdv->medecin->nom }} {{ $rdv->medecin->prenom }}</td>
                        <td>{{ \Carbon\Carbon::parse($rdv->date_heure)->format('d/m/Y') }}</td>
                        <td>{{ \Carbon\Carbon::parse($rdv->date_heure)->format('H:i') }}</td>
                        <td>
                            <select class="form-select form-select-sm statut-select" data-id="{{ $rdv->id }}" style="width: 120px;">
                                <option value="en_attente" {{ $rdv->statut == 'en_attente' ? 'selected' : '' }}>En attente</option>
                                <option value="confirme" {{ $rdv->statut == 'confirme' ? 'selected' : '' }}>Confirmé</option>
                                <option value="termine" {{ $rdv->statut == 'termine' ? 'selected' : '' }}>Terminé</option>
                                <option value="annule" {{ $rdv->statut == 'annule' ? 'selected' : '' }}>Annulé</option>
                            </select>
                        </td>
                        <td>{{ $rdv->motif ?? '-' }}</td>
                        <td>
                            <a href="{{ route('rendezvous.edit', $rdv->id) }}" class="btn btn-warning btn-sm">Modifier</a>
                            <form action="{{ route('rendezvous.destroy', $rdv->id) }}" method="POST" class="d-inline">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Supprimer ce rendez-vous ?')">Supprimer</button>
                            </form>
                        </td>
                        <td>
                            @if($rdv->statut == 'termine')
                                @if($rdv->consultation)
                                    <a href="{{ route('consultations.show', $rdv->consultation->id) }}" class="btn btn-sm btn-info">Voir consultation</a>
                                @else
                                    <span class="badge bg-secondary">Aucune</span>
                                @endif
                            @elseif($rdv->statut == 'confirme')
                                <a href="{{ route('consultations.create', $rdv->id) }}" class="btn btn-sm btn-success">Ajouter consultation</a>
                            @else
                                <span class="badge bg-secondary">-</span>
                            @endif
                        </td>
                    </tr>
                    @empty
                        <tr>
                            <td colspan="8" class="text-center text-muted py-4">
                                Aucun rendez-vous trouvé.
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    document.querySelectorAll('.statut-select').forEach(select => {
        select.addEventListener('change', function() {
            const id = this.dataset.id;
            const statut = this.value;
            
            fetch(`/rendezvous/${id}/statut`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                },
                body: JSON.stringify({ statut: statut })
            })
            .then(response => response.json())
            .then(data => {
                if(data.success) {
                    location.reload();
                }
            });
        });
    });
</script>
@endpush