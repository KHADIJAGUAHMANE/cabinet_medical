@extends('layouts.admin')

@section('title', 'Ajouter une disponibilité')

@section('content')
<div class="card shadow border-0 rounded-4">
    <div class="card-body">
        <form action="{{ route('disponibilites.store') }}" method="POST">
            @csrf

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label>Médecin</label>
                    <select name="medecin_id" class="form-control" required>
                        <option value="">Sélectionner</option>
                        @foreach($medecins as $medecin)
                            <option value="{{ $medecin->id }}">Dr. {{ $medecin->nom }} {{ $medecin->prenom }}</option>
                        @endforeach
                    </select>
                </div>

                <div class="col-md-6 mb-3">
                    <label>Jour</label>
                    <select name="jour" class="form-control" required>
                        @foreach($jours as $jour)
                            <option value="{{ $jour }}">{{ ucfirst($jour) }}</option>
                        @endforeach
                    </select>
                </div>

                <div class="col-md-6 mb-3">
                    <label>Heure début</label>
                    <input type="time" name="heure_debut" class="form-control" required>
                </div>

                <div class="col-md-6 mb-3">
                    <label>Heure fin</label>
                    <input type="time" name="heure_fin" class="form-control" required>
                </div>
            </div>

            <button type="submit" class="btn btn-primary">Enregistrer</button>
            <a href="{{ route('disponibilites.index') }}" class="btn btn-secondary">Annuler</a>
        </form>
    </div>
</div>
@endsection