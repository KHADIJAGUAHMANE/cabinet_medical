@extends('layouts.admin')

@section('title', 'Gestion des disponibilités')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold">📅 Disponibilités des médecins</h2>
    <a href="{{ route('disponibilites.create') }}" class="btn btn-primary">
        <i class="bi bi-plus-circle"></i> Ajouter une disponibilité
    </a>
</div>

<div class="card shadow border-0 rounded-4">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>Médecin</th>
                        <th>Jour</th>
                        <th>Heure début</th>
                        <th>Heure fin</th>
                        <th>Statut</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($disponibilites as $dispo)
                        <tr>
                            <td>Dr. {{ $dispo->medecin->nom }} {{ $dispo->medecin->prenom }}</td>
                            <td>{{ ucfirst($dispo->jour) }}</td>
                            <td>{{ $dispo->heure_debut }}</td>
                            <td>{{ $dispo->heure_fin }}</td>
                            <td>
                                <span class="badge bg-{{ $dispo->active ? 'success' : 'danger' }}">
                                    {{ $dispo->active ? 'Actif' : 'Inactif' }}
                                </span>
                            </td>
                            <td>
                                <a href="{{ route('disponibilites.edit', $dispo->id) }}" class="btn btn-sm btn-warning">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                <form action="{{ route('disponibilites.toggle', $dispo->id) }}" method="POST" class="d-inline">
                                    @csrf
                                    <button type="submit" class="btn btn-sm btn-{{ $dispo->active ? 'secondary' : 'success' }}">
                                        <i class="bi bi-{{ $dispo->active ? 'pause' : 'play' }}"></i>
                                    </button>
                                </form>
                                <form action="{{ route('disponibilites.destroy', $dispo->id) }}" method="POST" class="d-inline">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Supprimer ?')">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="6" class="text-center">Aucune disponibilité</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection