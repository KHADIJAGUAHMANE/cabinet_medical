@extends('layouts.admin')

@section('title', 'Historique médical - ' . $patient->user->nom . ' ' . $patient->user->prenom)

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold">
        <i class="bi bi-clock-history"></i> 
        Historique médical de {{ $patient->user->nom }} {{ $patient->user->prenom }}
    </h2>
    <div>
        <a href="{{ route('patients.show', $patient->id) }}" class="btn btn-info">
            <i class="bi bi-person"></i> Fiche patient
        </a>
        <a href="{{ route('patients.index') }}" class="btn btn-secondary">
            <i class="bi bi-arrow-left"></i> Retour
        </a>
    </div>
</div>

<!-- Informations patient -->
<div class="card shadow border-0 rounded-4 mb-4">
    <div class="card-header bg-white">
        <h5 class="mb-0">Informations patient</h5>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-3">
                <strong>Nom complet :</strong><br>
                {{ $patient->user->nom }} {{ $patient->user->prenom }}
            </div>
            <div class="col-md-3">
                <strong>Date naissance :</strong><br>
                {{ $patient->date_naissance ?? 'Non renseignée' }}
            </div>
            <div class="col-md-3">
                <strong>Téléphone :</strong><br>
                {{ $patient->user->telephone ?? '-' }}
            </div>
            <div class="col-md-3">
                <strong>Email :</strong><br>
                {{ $patient->user->email }}
            </div>
        </div>
    </div>
</div>

<!-- Historique des consultations -->
<div class="card shadow border-0 rounded-4">
    <div class="card-header bg-white">
        <h5 class="mb-0">
            <i class="bi bi-file-text"></i> 
            Consultations médicales ({{ $consultations->count() }})
        </h5>
    </div>
    <div class="card-body">
        @forelse($consultations as $consultation)
            <div class="card mb-3 border">
                <div class="card-header bg-light">
                    <div class="row">
                        <div class="col-md-4">
                            <strong>📅 Date :</strong> 
                            {{ \Carbon\Carbon::parse($consultation->date_heure)->format('d/m/Y H:i') }}
                        </div>
                        <div class="col-md-4">
                            <strong>👨‍⚕️ Médecin :</strong> 
                            Dr. {{ $consultation->medecin->nom }} {{ $consultation->medecin->prenom }}
                        </div>
                        <div class="col-md-4">
                            <strong>🏷️ Spécialité :</strong> 
                            {{ $consultation->medecin->specialite ?? 'Généraliste' }}
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12 mb-3">
                            <strong>📝 Motif :</strong>
                            <p class="mt-2">{{ $consultation->motif ?? 'Non spécifié' }}</p>
                        </div>
                        
                        @if($consultation->consultation)
                            <div class="col-md-12 mb-3">
                                <strong>🩺 Compte-rendu :</strong>
                                <p class="mt-2">{{ $consultation->consultation->compte_rendu }}</p>
                            </div>
                            
                            @if($consultation->consultation->ordonnance)
                                <div class="col-md-12">
                                    <strong>💊 Ordonnance :</strong>
                                    <p class="mt-2">{{ $consultation->consultation->ordonnance->contenu }}</p>
                                    <a href="{{ route('ordonnances.pdf', $consultation->consultation->ordonnance->id) }}" 
                                       class="btn btn-sm btn-primary mt-2">
                                        <i class="bi bi-file-pdf"></i> Télécharger PDF
                                    </a>
                                </div>
                            @endif
                        @else
                            <div class="col-md-12">
                                <span class="badge bg-warning">Aucun compte-rendu disponible</span>
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        @empty
            <div class="text-center py-5">
                <i class="bi bi-inbox fs-1 text-muted"></i>
                <p class="text-muted mt-2">Aucune consultation terminée pour ce patient.</p>
            </div>
        @endforelse
    </div>
</div>
@endsection