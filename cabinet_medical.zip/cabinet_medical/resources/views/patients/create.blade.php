@extends('layouts.admin')

@section('content')
<div class="container-fluid">

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold text-primary">Ajouter un patient</h2>
        <a href="{{ route('patients.index') }}" class="btn btn-secondary rounded-3">
            Retour
        </a>
    </div>

    <div class="card shadow border-0 rounded-4">
        <div class="card-body p-4">

            <form method="POST" action="{{ route('patients.store') }}">
                @csrf

                <div class="row">

                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-bold">Utilisateur</label>
                        <select name="user_id" class="form-select rounded-3" required>
                            <option value="">Choisir un utilisateur</option>
                            @foreach($users as $user)
                                <option value="{{ $user->id }}">
                                    {{ $user->nom }} {{ $user->prenom }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-bold">Date de naissance</label>
                        <input type="date" name="date_naissance" class="form-control rounded-3" required>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-bold">Sexe</label>
                        <select name="sexe" class="form-select rounded-3" required>
                            <option value="">Choisir</option>
                            <option value="M">Masculin</option>
                            <option value="F">Féminin</option>
                        </select>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-bold">Adresse</label>
                        <input type="text" name="adresse" class="form-control rounded-3" placeholder="Entrer l'adresse">
                    </div>

                    <div class="col-12 mb-4">
                        <label class="form-label fw-bold">Historique médical</label>
                        <textarea name="historique_medical" class="form-control rounded-3" rows="4" placeholder="Historique médical du patient"></textarea>
                    </div>

                </div>

                <button type="submit" class="btn btn-primary rounded-3 px-4">
                    Ajouter le patient
                </button>
            </form>

        </div>
    </div>
</div>
@endsection
