@extends('layouts.admin')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold">Liste des Patients</h2>

    <a href="{{ route('patients.create') }}" class="btn btn-primary">
        Ajouter un patient
    </a>
</div>

<div class="card shadow border-0 rounded-4">
    <div class="card-body">

        <form method="GET" action="{{ route('patients.index') }}" class="mb-4">
            <div class="row">
                <div class="col-md-10">
                    <input type="text" name="search" class="form-control" placeholder="Rechercher un patient..." value="{{ request('search') }}">
                </div>
                <div class="col-md-2">
                    <button class="btn btn-dark w-100">Rechercher</button>
                </div>
            </div>
        </form>

        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>Nom</th>
                        <th>Prénom</th>
                        <th>Email</th>
                        <th>Téléphone</th>
                        <th>Date naissance</th>
                        <th>Sexe</th>
                        <th>Adresse</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>
                    @forelse($patients as $patient)
                        <tr>
                            <td>{{ $patient->user->nom }}</td>
                            <td>{{ $patient->user->prenom }}</td>
                            <td>{{ $patient->user->email }}</td>
                            <td>{{ $patient->user->telephone }}</td>
                            <td>{{ $patient->date_naissance }}</td>
                            <td>{{ $patient->sexe }}</td>
                            <td>{{ $patient->adresse }}</td>
                            <td>
                            <a href="{{ route('patients.edit', $patient->id) }}" class="btn btn-warning btn-sm">Modifier</a>
                            <a href="{{ route('patients.show', $patient->id) }}" class="btn btn-info btn-sm">Voir</a>
                            <form action="{{ route('patients.destroy', $patient->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Supprimer ce patient ?')">
                            @csrf
                             @method('DELETE')
                            <button type="submit" class="btn btn-danger btn-sm">Supprimer</button>
                        </form>
                        </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="8" class="text-center text-muted">
                                Aucun patient trouvé
                            </td>
                        </tr>
                    @endforelse
                </tbody>

            </table>
        </div>

    </div>
</div>

@endsection