@extends('layouts.admin')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold">Détails du Patient</h2>
    <div>
        <a href="{{ route('patients.edit', $patient->id) }}" class="btn btn-warning">Modifier</a>
        <a href="{{ route('patients.index') }}" class="btn btn-secondary">Retour</a>
    </div>
</div>
<a href="{{ route('patients.historique', $patient->id) }}" class="btn btn-info mt-3">
    <i class="bi bi-clock-history"></i> Voir historique médical
</a>
<div class="card shadow border-0 rounded-4">
    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <table class="table table-bordered">
                    <tr>
                        <th width="40%">Nom complet</th>
                        <td>{{ $patient->user->nom }} {{ $patient->user->prenom }}</td>
                    </tr>
                    <tr>
                        <th>Email</th>
                        <td>{{ $patient->user->email }}</td>
                    </tr>
                    <tr>
                        <th>Téléphone</th>
                        <td>{{ $patient->user->telephone ?? 'Non renseigné' }}</td>
                    </tr>
                    <tr>
                        <th>Date de naissance</th>
                        <td>{{ $patient->date_naissance ?? 'Non renseignée' }}</td>
                    </tr>
                    <tr>
                        <th>Sexe</th>
                        <td>{{ $patient->sexe == 'M' ? 'Masculin' : 'Féminin' }}</td>
                    </tr>
                    <tr>
                        <th>Adresse</th>
                        <td>{{ $patient->adresse ?? 'Non renseignée' }}</td>
                    </tr>
                    <tr>
                        <th>Date d'inscription</th>
                        <td>{{ $patient->created_at->format('d/m/Y H:i') }}</td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</div>

@if(isset($patient->rendezvous) && $patient->rendezvous->count() > 0)
<div class="card shadow border-0 rounded-4 mt-4">
    <div class="card-header bg-dark text-white">
        <h5 class="mb-0">Historique des rendez-vous</h5>
    </div>
    <div class="card-body">
        <table class="table">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Heure</th>
                    <th>Statut</th>
                </tr>
            </thead>
            <tbody>
                @foreach($patient->rendezvous as $rdv)
                <tr>
                    <td>{{ $rdv->date }}</td>
                    <td>{{ $rdv->heure }}</td>
                    <td>
                        <span class="badge bg-{{ $rdv->statut == 'confirme' ? 'success' : 'warning' }}">
                            {{ $rdv->statut }}
                        </span>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@endif

@endsection