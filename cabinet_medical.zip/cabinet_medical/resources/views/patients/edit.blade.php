@extends('layouts.admin')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold">Modifier un Patient</h2>
    <a href="{{ route('patients.index') }}" class="btn btn-secondary">Retour à la liste</a>
</div>

<div class="card shadow border-0 rounded-4">
    <div class="card-body">
        <form action="{{ route('patients.update', $patient->id) }}" method="POST">
            @csrf
            @method('PUT')

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="nom" class="form-label">Nom</label>
                    <input type="text" name="nom" class="form-control" value="{{ old('nom', $patient->user->nom) }}" required>
                </div>

                <div class="col-md-6 mb-3">
                    <label for="prenom" class="form-label">Prénom</label>
                    <input type="text" name="prenom" class="form-control" value="{{ old('prenom', $patient->user->prenom) }}" required>
                </div>

                <div class="col-md-6 mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" name="email" class="form-control" value="{{ old('email', $patient->user->email) }}" required>
                </div>

                <div class="col-md-6 mb-3">
                    <label for="telephone" class="form-label">Téléphone</label>
                    <input type="text" name="telephone" class="form-control" value="{{ old('telephone', $patient->user->telephone) }}">
                </div>

                <div class="col-md-6 mb-3">
                    <label for="date_naissance" class="form-label">Date de naissance</label>
                    <input type="date" name="date_naissance" class="form-control" value="{{ old('date_naissance', $patient->date_naissance) }}">
                </div>

                <div class="col-md-6 mb-3">
                    <label for="sexe" class="form-label">Sexe</label>
                    <select name="sexe" class="form-control">
                        <option value="M" {{ $patient->sexe == 'M' ? 'selected' : '' }}>Masculin</option>
                        <option value="F" {{ $patient->sexe == 'F' ? 'selected' : '' }}>Féminin</option>
                    </select>
                </div>

                <div class="col-md-12 mb-3">
                    <label for="adresse" class="form-label">Adresse</label>
                    <textarea name="adresse" class="form-control" rows="2">{{ old('adresse', $patient->adresse) }}</textarea>
                </div>
            </div>

            <div class="text-end">
                <button type="submit" class="btn btn-primary">Mettre à jour</button>
            </div>
        </form>
    </div>
</div>
@endsection