<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use App\Models\MedicalPatient;
use App\Models\MedicalRendezVous;
use App\Models\MedicalConsultation;
use App\Models\MedicalOrdonnance;
use App\Models\Disponibilite;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;

class DatabaseSeeder extends Seeder
{
    public function run()
    {
        // Admin
        User::create([
            'nom' => 'Admin',
            'prenom' => 'System',
            'email' => 'admin@cabinet.ma',
            'password' => Hash::make('password'),
            'role' => 'admin',
            'telephone' => '0612345678'
        ]);
        
        // Médecins
        $medecins = [
            ['nom' => 'Alaoui', 'prenom' => 'Ahmed', 'email' => 'medecin1@cabinet.ma', 'specialite' => 'Généraliste'],
            ['nom' => 'Benzakour', 'prenom' => 'Sanae', 'email' => 'medecin2@cabinet.ma', 'specialite' => 'Pédiatrie'],
            ['nom' => 'GHAZOUI', 'prenom' => 'HOUDA', 'email' => 'medecin3@cabinet.ma', 'specialite' => 'Cardiologie'],
        ];
        
        foreach($medecins as $m) {
            User::create([
                'nom' => $m['nom'],
                'prenom' => $m['prenom'],
                'email' => $m['email'],
                'password' => Hash::make('password'),
                'role' => 'medecin',
                'specialite' => $m['specialite'],
                'telephone' => '06' . rand(10000000, 99999999)
            ]);
        }
        
        // Secrétaire
        User::create([
            'nom' => 'Secrétaire',
            'prenom' => 'Test',
            'email' => 'secretaire@cabinet.ma',
            'password' => Hash::make('password'),
            'role' => 'secretaire',
            'telephone' => '0612345679'
        ]);
        
        // Patients (5 patients)
        for($i = 1; $i <= 5; $i++) {
            $user = User::create([
                'nom' => 'Patient' . $i,
                'prenom' => 'Test',
                'email' => 'patient' . $i . '@test.com',
                'password' => Hash::make('password'),
                'role' => 'patient',
                'telephone' => '06' . rand(10000000, 99999999)
            ]);
            
            MedicalPatient::create([
                'user_id' => $user->id,
                'date_naissance' => Carbon::now()->subYears(rand(20, 60))->format('Y-m-d'),
                'adresse' => rand(1, 100) . ' Rue de Paris, Casablanca',
                'sexe' => rand(0, 1) ? 'M' : 'F'
            ]);
        }
        
        // Disponibilités
        $jours = ['lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi'];
        $medecinIds = User::where('role', 'medecin')->pluck('id');
        
        foreach($medecinIds as $medecinId) {
            foreach($jours as $jour) {
                Disponibilite::create([
                    'medecin_id' => $medecinId,
                    'jour' => $jour,
                    'heure_debut' => '09:00:00',
                    'heure_fin' => '12:00:00',
                    'active' => true
                ]);
                Disponibilite::create([
                    'medecin_id' => $medecinId,
                    'jour' => $jour,
                    'heure_debut' => '14:00:00',
                    'heure_fin' => '17:00:00',
                    'active' => true
                ]);
            }
        }
        
        // Rendez-vous (20 rendez-vous)
        $patients = MedicalPatient::all();
        
        for($i = 1; $i <= 20; $i++) {
            $rdv = MedicalRendezVous::create([
                'patient_id' => $patients->random()->id,
                'user_id_medecin' => $medecinIds->random(),
                'date_heure' => Carbon::now()->subDays(rand(0, 60))->setTime(rand(9, 16), 0, 0),
                'statut' => ['en_attente', 'confirme', 'termine', 'annule'][rand(0, 3)],
                'motif' => 'Motif consultation ' . $i
            ]);
            
            // Consultations pour les rendez-vous terminés ou confirmés
            if($rdv->statut == 'termine' || ($rdv->statut == 'confirme' && $i % 2 == 0)) {
                $consultation = MedicalConsultation::create([
                    'rendez_vous_id' => $rdv->id,
                    'medecin_id' => $rdv->user_id_medecin,
                    'patient_id' => $rdv->patient_id,
                    'compte_rendu' => 'Consultation normale. Patient en bonne santé générale.',
                    'diagnostic' => ['RAS', 'Grippe', 'Hypertension', 'Allergie'][rand(0, 3)],
                    'traitement' => ['Repos', 'Paracétamol', 'Antibiotique', 'Aucun'][rand(0, 3)],
                    'date_consultation' => Carbon::parse($rdv->date_heure)->format('Y-m-d')
                ]);
                
                // Ordonnances pour certaines consultations
                if($i % 3 == 0) {
                    MedicalOrdonnance::create([
                        'consultation_id' => $consultation->id,
                        'patient_id' => $rdv->patient_id,
                        'numero_ordonnance' => 'ORD-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -6)),
                        'date_ordonnance' => Carbon::now()->format('Y-m-d'),
                        'medicaments' => "Paracétamol 500mg\nVitamine C\n" . ($i % 2 == 0 ? 'Amoxicilline 250mg' : ''),
                        'posologies' => '3 fois par jour pendant 5 jours',
                        'recommandations' => 'Repos, boire beaucoup d\'eau'
                    ]);
                }
            }
        }
        
        $this->command->info('✅ 20 rendez-vous créés !');
        $this->command->info('✅ Compte admin: admin@cabinet.ma / password');
        $this->command->info('✅ Compte médecin: medecin1@cabinet.ma / password');
        $this->command->info('✅ Compte patient: patient1@test.com / password');
    }
}