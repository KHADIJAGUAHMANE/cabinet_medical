<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use App\Models\MedicalPatient;
use App\Models\MedicalRendezVous;
use Carbon\Carbon;

class TestDataSeeder extends Seeder
{
    public function run()
    {
        // Rendez-vous des 6 derniers mois
        for ($i = 1; $i <= 20; $i++) {
            MedicalRendezVous::create([
                'patient_id' => rand(1, 2),
                'user_id_medecin' => rand(2, 4),
                'date_heure' => Carbon::now()->subDays(rand(0, 180)),
                'statut' => ['en_attente', 'confirme', 'termine', 'annule'][rand(0, 3)],
                'motif' => 'Motif test ' . $i,
            ]);
        }
    }
}
