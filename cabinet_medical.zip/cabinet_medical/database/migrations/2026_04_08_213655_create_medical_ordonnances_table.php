<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('medical_ordonnances', function (Blueprint $table) {
            $table->id();
            $table->foreignId('consultation_id')->constrained('medical_consultations')->onDelete('cascade');
            $table->foreignId('patient_id')->constrained('medical_patients')->onDelete('cascade');
            $table->string('numero_ordonnance')->unique();
            $table->date('date_ordonnance');
            $table->text('medicaments');
            $table->text('posologies')->nullable();
            $table->text('recommandations')->nullable();
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('medical_ordonnances');
    }
};
