<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('medical_consultations', function (Blueprint $table) {
            $table->id();
            $table->foreignId('rendez_vous_id')->constrained('medical_rendez_vous')->onDelete('cascade');
            $table->foreignId('medecin_id')->constrained('users')->onDelete('cascade');
            $table->foreignId('patient_id')->constrained('medical_patients')->onDelete('cascade');
            $table->text('compte_rendu');
            $table->text('diagnostic')->nullable();
            $table->text('traitement')->nullable();
            $table->date('date_consultation');
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('medical_consultations');
    }
};
