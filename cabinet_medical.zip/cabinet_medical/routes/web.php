<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Models\User;
use App\Http\Controllers\PatientController; 
use App\Http\Controllers\RendezVousController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\DisponibiliteController;  // ← AJOUTEZ CETTE LIGNE

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

Route::get('/', function () {
    return view('welcome');
});

// Routes de Connexion
Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
Route::post('/login', [AuthController::class, 'login']);
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

// Routes pour les invités (Guest)
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
    Route::post('/login', [AuthController::class, 'login']);
    Route::get('/register', [AuthController::class, 'showRegisterForm'])->name('register');
    Route::post('/register', [AuthController::class, 'register']);
});

// Routes protégées par authentification
Route::middleware(['auth'])->group(function () {
    
    Route::get('/home', function () {
        return redirect('/dashboard');
    });
    
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    
    Route::resource('patients', PatientController::class);
    Route::resource('rendezvous', RendezVousController::class);
    
    // Historique patient
    Route::get('/patients/{id}/historique', [PatientController::class, 'historique'])->name('patients.historique');
    
    // Route pour changer le statut d'un rendez-vous (AJAX)
    Route::post('/rendezvous/{id}/statut', [RendezVousController::class, 'updateStatut'])->name('rendezvous.statut');
    
    // Route pour le calendrier des rendez-vous
    Route::get('/calendrier', [RendezVousController::class, 'calendar'])->name('rendezvous.calendar');
    
    // Routes pour les disponibilités (dans le groupe auth)
    Route::resource('disponibilites', DisponibiliteController::class);
    Route::post('/disponibilites/{id}/toggle', [DisponibiliteController::class, 'toggle'])->name('disponibilites.toggle');
});

// Routes protégées par authentification + rôle admin
Route::middleware(['auth', 'admin'])->group(function () {
    Route::resource('users', UserController::class);
});
use App\Http\Controllers\ConsultationController;

// Routes consultations
Route::middleware(['auth'])->group(function () {
    Route::resource('consultations', ConsultationController::class);
    Route::get('/consultations/create/{rendez_vous_id}', [ConsultationController::class, 'create'])->name('consultations.create');
    Route::get('/consultations/ordonnance/{consultation_id}', [ConsultationController::class, 'ordonnance'])->name('consultations.ordonnance');
    Route::post('/consultations/ordonnance/{consultation_id}', [ConsultationController::class, 'storeOrdonnance'])->name('consultations.ordonnance.store');
    Route::get('/consultations/pdf/{ordonnance_id}', [ConsultationController::class, 'exportPdf'])->name('consultations.ordonnance.pdf');
    Route::get('/patients/{id}/historique', [ConsultationController::class, 'historique'])->name('patients.historique');
});