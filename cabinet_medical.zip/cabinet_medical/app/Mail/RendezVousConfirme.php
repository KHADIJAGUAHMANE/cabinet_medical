<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class RendezVousConfirme extends Mailable
{
    use Queueable, SerializesModels;

    public $rendezvous;

    public function __construct($rendezvous)
    {
        $this->rendezvous = $rendezvous;
    }

    public function build()
    {
        return $this->subject('Confirmation de rendez-vous')
                    ->view('emails.rendezvous');
    }
}


