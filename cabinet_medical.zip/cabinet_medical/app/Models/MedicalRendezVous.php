<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MedicalRendezVous extends Model
{
    use HasFactory;

    protected $table = 'medical_rendez_vous';

    protected $fillable = [
        'patient_id',
        'user_id_medecin',
        'date_heure',
        'statut',
        'motif'
    ];

    public function patient()
    {
        return $this->belongsTo(MedicalPatient::class, 'patient_id');
    }

    public function medecin()
    {
        return $this->belongsTo(User::class, 'user_id_medecin');
    }
    public function consultation()
{
    return $this->hasOne(MedicalConsultation::class, 'rendez_vous_id');
}
}