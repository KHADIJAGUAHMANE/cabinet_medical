<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Disponibilite extends Model
{
    protected $fillable = [
        'medecin_id',
        'jour',
        'heure_debut',
        'heure_fin',
        'active'
    ];

    public function medecin()
    {
        return $this->belongsTo(User::class, 'medecin_id');
    }
}