<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MedicalOrdonnance extends Model
{
    protected $table = 'medical_ordonnances';
    
    protected $fillable = [
        'consultation_id',
        'patient_id',
        'numero_ordonnance',
        'date_ordonnance',
        'medicaments',
        'posologies',
        'recommandations'
    ];
    
    public function consultation()
    {
        return $this->belongsTo(MedicalConsultation::class, 'consultation_id');
    }
    
    public function patient()
    {
        return $this->belongsTo(MedicalPatient::class, 'patient_id');
    }
}