<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MedicalConsultation extends Model
{
    protected $table = 'medical_consultations';
    
    protected $fillable = [
        'rendez_vous_id',
        'medecin_id',
        'patient_id',
        'compte_rendu',
        'diagnostic',
        'traitement',
        'date_consultation'
    ];
    
    public function rendezVous()
    {
        return $this->belongsTo(MedicalRendezVous::class, 'rendez_vous_id');
    }
    
    public function medecin()
    {
        return $this->belongsTo(User::class, 'medecin_id');
    }
    
    public function patient()
    {
        return $this->belongsTo(MedicalPatient::class, 'patient_id');
    }
    
    public function ordonnance()
    {
        return $this->hasOne(MedicalOrdonnance::class, 'consultation_id');
    }
}