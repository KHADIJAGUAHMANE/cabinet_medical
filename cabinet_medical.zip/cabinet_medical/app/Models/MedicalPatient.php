<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MedicalPatient extends Model
{
    use HasFactory;

    protected $table = 'medical_patients';

    protected $fillable = [
        'user_id',
        'date_naissance',
        'sexe',
        'adresse',
        'historique_medical'
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function rendezVous()
    {
        return $this->hasMany(MedicalRendezVous::class, 'patient_id');
    }
}

