<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\MedicalPatient;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    // Formulaire login
    public function showLoginForm()
    {
        return view('auth.login');
    }

    // Login
    public function login(Request $request)
    {
        $credentials = $request->only('email', 'password');

        if (Auth::attempt($credentials)) {
            return redirect()->route('dashboard');
        }

        return back()->withErrors([
            'email' => 'Email ou mot de passe incorrect'
        ]);
    }

    // Logout
    public function logout()
    {
        Auth::logout();
        return redirect('/login');
    }

    // Formulaire register
    public function showRegisterForm()
    {
        return view('auth.register');
    }

    // Enregistrement patient (UNE SEULE VERSION)
    public function register(Request $request)
    {
        $request->validate([
            'nom' => 'required|string|max:255',
            'prenom' => 'required|string|max:255',
            'email' => 'required|email|unique:users',
            'password' => 'required|min:6|confirmed',
            'telephone' => 'nullable|string',
            'date_naissance' => 'nullable|date',
            'adresse' => 'nullable|string',
            'sexe' => 'nullable|in:M,F',
        ]);

        // Créer l'utilisateur (rôle = patient)
        $user = User::create([
            'nom' => $request->nom,
            'prenom' => $request->prenom,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'role' => 'patient',
            'telephone' => $request->telephone,
        ]);

        // Créer la fiche médicale
        MedicalPatient::create([
            'user_id' => $user->id,
            'date_naissance' => $request->date_naissance,
            'adresse' => $request->adresse,
            'sexe' => $request->sexe,
        ]);

        // Connexion automatique
        auth()->login($user);

        return redirect()->route('dashboard')->with('success', 'Bienvenue ! Vous pouvez maintenant prendre rendez-vous.');
    }
}