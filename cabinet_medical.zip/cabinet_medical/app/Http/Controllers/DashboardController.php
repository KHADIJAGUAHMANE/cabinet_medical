<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\MedicalPatient;
use App\Models\MedicalRendezVous;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index()
    {
        $total = User::count();
        $patients = User::where('role', 'patient')->count();
        $medecins = User::where('role', 'medecin')->count();
        $secretaires = User::where('role', 'secretaire')->count();
        $totalRendezVous = MedicalRendezVous::count();
        
        $rdvConfirme = MedicalRendezVous::where('statut', 'confirme')->count();
        $rdvEnAttente = MedicalRendezVous::where('statut', 'en_attente')->count();
        $rdvAnnule = MedicalRendezVous::where('statut', 'annule')->count();
        $rdvTermine = MedicalRendezVous::where('statut', 'termine')->count();
        
        $rdvParMois = MedicalRendezVous::select(
            DB::raw('MONTH(date_heure) as mois'),
            DB::raw('COUNT(*) as total')
        )
        ->whereYear('date_heure', date('Y'))
        ->groupBy('mois')
        ->orderBy('mois')
        ->get();
        
        $moisLabels = ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'];
        $nbRdvParMois = array_fill(0, 12, 0);
        
        foreach($rdvParMois as $rdv) {
            $nbRdvParMois[$rdv->mois - 1] = $rdv->total;
        }
        
        $topMedecins = User::where('role', 'medecin')
            ->withCount('rendezvous')
            ->orderBy('rendezvous_count', 'desc')
            ->limit(5)
            ->get();
        
        return view('dashboard', compact(
            'total',
            'patients',
            'medecins',
            'secretaires',
            'totalRendezVous',
            'rdvConfirme',
            'rdvEnAttente',
            'rdvAnnule',
            'rdvTermine',
            'moisLabels',
            'nbRdvParMois',
            'topMedecins'
        ));
    }
}