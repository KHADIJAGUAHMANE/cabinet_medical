<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Disponibilite;
use Illuminate\Http\Request;

class DisponibiliteController extends Controller
{
    public function index()
    {
        $medecins = User::where('role', 'medecin')->get();
        $disponibilites = Disponibilite::with('medecin')->get();
        return view('disponibilites.index', compact('medecins', 'disponibilites'));
    }

    public function create()
    {
        $medecins = User::where('role', 'medecin')->get();
        $jours = ['lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi', 'dimanche'];
        return view('disponibilites.create', compact('medecins', 'jours'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'medecin_id' => 'required|exists:users,id',
            'jour' => 'required',
            'heure_debut' => 'required',
            'heure_fin' => 'required|after:heure_debut'
        ]);

        Disponibilite::create($request->all());
        return redirect()->route('disponibilites.index')->with('success', 'Disponibilité ajoutée');
    }

    public function edit($id)
    {
        $disponibilite = Disponibilite::findOrFail($id);
        $medecins = User::where('role', 'medecin')->get();
        $jours = ['lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi', 'dimanche'];
        return view('disponibilites.edit', compact('disponibilite', 'medecins', 'jours'));
    }

    public function update(Request $request, $id)
    {
        $disponibilite = Disponibilite::findOrFail($id);
        
        $request->validate([
            'medecin_id' => 'required|exists:users,id',
            'jour' => 'required',
            'heure_debut' => 'required',
            'heure_fin' => 'required|after:heure_debut'
        ]);

        $disponibilite->update($request->all());
        return redirect()->route('disponibilites.index')->with('success', 'Disponibilité modifiée');
    }

    public function destroy($id)
    {
        $disponibilite = Disponibilite::findOrFail($id);
        $disponibilite->delete();
        return redirect()->route('disponibilites.index')->with('success', 'Disponibilité supprimée');
    }

    public function toggle($id)
    {
        $disponibilite = Disponibilite::findOrFail($id);
        $disponibilite->active = !$disponibilite->active;
        $disponibilite->save();
        return redirect()->route('disponibilites.index')->with('success', 'Statut modifié');
    }
}