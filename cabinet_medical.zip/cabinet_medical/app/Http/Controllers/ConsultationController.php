<?php

namespace App\Http\Controllers;

use App\Models\MedicalRendezVous;
use App\Models\MedicalConsultation;
use App\Models\MedicalOrdonnance;
use Illuminate\Http\Request;
use Carbon\Carbon;

class ConsultationController extends Controller
{
    // Liste des consultations
    public function index()
    {
        if(auth()->user()->role == 'medecin') {
            $consultations = MedicalConsultation::where('medecin_id', auth()->user()->id)
                ->with(['patient.user', 'rendezVous'])
                ->orderBy('created_at', 'desc')
                ->get();
        } else {
            $consultations = MedicalConsultation::with(['patient.user', 'medecin', 'rendezVous'])
                ->orderBy('created_at', 'desc')
                ->get();
        }
        
        return view('consultations.index', compact('consultations'));
    }
    
    // Formulaire création consultation
    public function create($rendez_vous_id)
    {
        $rdv = MedicalRendezVous::with(['patient.user', 'medecin'])->findOrFail($rendez_vous_id);
        
        if($rdv->statut != 'termine' && $rdv->statut != 'confirme') {
            return redirect()->route('rendezvous.index')->with('error', 'Ce rendez-vous ne peut pas encore être consulté.');
        }
        
        return view('consultations.create', compact('rdv'));
    }
    
    // Enregistrer consultation
    public function store(Request $request)
    {
        $request->validate([
            'rendez_vous_id' => 'required|exists:medical_rendez_vous,id',
            'compte_rendu' => 'required|string',
            'diagnostic' => 'nullable|string',
            'traitement' => 'nullable|string',
        ]);
        
        $rdv = MedicalRendezVous::findOrFail($request->rendez_vous_id);
        
        $consultation = MedicalConsultation::create([
            'rendez_vous_id' => $request->rendez_vous_id,
            'medecin_id' => auth()->user()->id,
            'patient_id' => $rdv->patient_id,
            'compte_rendu' => $request->compte_rendu,
            'diagnostic' => $request->diagnostic,
            'traitement' => $request->traitement,
            'date_consultation' => Carbon::now()->format('Y-m-d'),
        ]);
        
        $rdv->statut = 'termine';
        $rdv->save();
        
        return redirect()->route('consultations.show', $consultation->id)->with('success', 'Consultation enregistrée');
    }
    
    // Afficher consultation
    public function show($id)
    {
        $consultation = MedicalConsultation::with(['patient.user', 'medecin', 'rendezVous', 'ordonnance'])->findOrFail($id);
        return view('consultations.show', compact('consultation'));
    }
    
    // Historique médical d'un patient
    public function historique($patient_id)
    {
        $patient = MedicalPatient::with('user')->findOrFail($patient_id);
        $consultations = MedicalConsultation::where('patient_id', $patient_id)
            ->with(['medecin', 'ordonnance'])
            ->orderBy('date_consultation', 'desc')
            ->get();
        
        return view('patients.historique', compact('patient', 'consultations'));
    }
    
    // Formulaire ordonnance
    public function ordonnance($consultation_id)
    {
        $consultation = MedicalConsultation::with(['patient.user', 'medecin'])->findOrFail($consultation_id);
        $ordonnance = MedicalOrdonnance::where('consultation_id', $consultation_id)->first();
        
        return view('consultations.ordonnance', compact('consultation', 'ordonnance'));
    }
    
    // Enregistrer ordonnance
    public function storeOrdonnance(Request $request, $consultation_id)
    {
        $request->validate([
            'medicaments' => 'required|string',
            'posologies' => 'nullable|string',
            'recommandations' => 'nullable|string',
        ]);
        
        $consultation = MedicalConsultation::findOrFail($consultation_id);
        
        $numero = 'ORD-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -6));
        
        $ordonnance = MedicalOrdonnance::create([
            'consultation_id' => $consultation_id,
            'patient_id' => $consultation->patient_id,
            'numero_ordonnance' => $numero,
            'date_ordonnance' => Carbon::now()->format('Y-m-d'),
            'medicaments' => $request->medicaments,
            'posologies' => $request->posologies,
            'recommandations' => $request->recommandations,
        ]);
        
        return redirect()->route('consultations.show', $consultation_id)->with('success', 'Ordonnance créée');
    }
    
    // Exporter PDF (avec impression navigateur - simple et fiable)
    public function exportPdf($ordonnance_id)
    {
        $ordonnance = MedicalOrdonnance::with(['consultation.medecin', 'patient.user'])->findOrFail($ordonnance_id);
        return view('consultations.pdf', compact('ordonnance'));
    }
}
