<?php

namespace App\Http\Controllers;

use App\Models\MedicalPatient;
use App\Models\User;
use Illuminate\Http\Request;

class PatientController extends Controller
{
    public function index(Request $request)
    {
        $search = $request->search;

        $patients = MedicalPatient::with('user')
            ->when($search, function ($query) use ($search) {
                $query->whereHas('user', function ($q) use ($search) {
                    $q->where('nom', 'like', "%$search%")
                      ->orWhere('prenom', 'like', "%$search%")
                      ->orWhere('email', 'like', "%$search%");
                });
            })
            ->get();

        return view('patients.index', compact('patients'));
    }

    public function create()
    {
        $users = User::where('role', 'patient')->get();
        return view('patients.create', compact('users'));
    }

    public function store(Request $request)
    {
        MedicalPatient::create($request->all());

        return redirect()->route('patients.index')->with('success', 'Patient ajouté');
    }
    public function edit($id)
{
    $patient = MedicalPatient::with('user')->findOrFail($id);
    return view('patients.edit', compact('patient'));
}

public function update(Request $request, $id)
{
    $patient = MedicalPatient::findOrFail($id);
    $patient->update($request->all());
    
    // Mettre à jour l'utilisateur associé
    $user = $patient->user;
    $user->update($request->all());
    
    return redirect()->route('patients.index')->with('success', 'Patient modifié');
}

public function destroy($id)
{
    $patient = MedicalPatient::findOrFail($id);
    $user = $patient->user;
    $patient->delete();
    $user->delete();
    
    return redirect()->route('patients.index')->with('success', 'Patient supprimé');
}

public function show($id)
{
    $patient = MedicalPatient::with('user')->findOrFail($id);
    return view('patients.show', compact('patient'));
}
// Afficher l'historique médical d'un patient
public function historique($id)
{
    $patient = MedicalPatient::with(['user', 'rendezvous.consultation', 'rendezvous.medecin'])
        ->findOrFail($id);
    
    $consultations = $patient->rendezvous()
        ->where('statut', 'termine')
        ->with('consultation', 'medecin')
        ->orderBy('date_heure', 'desc')
        ->get();
    
    return view('patients.historique', compact('patient', 'consultations'));
}
}


