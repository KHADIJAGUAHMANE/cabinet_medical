<?php

namespace App\Http\Controllers;

use App\Models\MedicalPatient;
use App\Models\MedicalRendezVous;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use App\Mail\RendezVousConfirme;
use Carbon\Carbon;

class RendezVousController extends Controller
{
    // Afficher la liste des rendez-vous
    public function index()
    {
        if(auth()->user()->role == 'medecin') {
            $rendezvous = MedicalRendezVous::where('user_id_medecin', auth()->user()->id)
                ->with(['patient.user', 'medecin'])
                ->orderBy('date_heure', 'desc')
                ->get();
        } else {
            $rendezvous = MedicalRendezVous::with(['patient.user', 'medecin'])
                ->orderBy('date_heure', 'desc')
                ->get();
        }
        
        return view('rendezvous.index', compact('rendezvous'));
    }
    
    // Formulaire de création (CORRIGÉ - UNE SEULE FOIS)
    public function create()
    {
        // Si c'est un patient, il prend RDV pour lui-même
        if(auth()->user()->role == 'patient') {
            $patients = MedicalPatient::where('user_id', auth()->user()->id)->get();
        } else {
            $patients = MedicalPatient::with('user')->get();
        }
        
        $medecins = User::where('role', 'medecin')->get();
        return view('rendezvous.create', compact('patients', 'medecins'));
    }
    
    // Enregistrer un rendez-vous
    public function store(Request $request)
    {
        $request->validate([
            'patient_id' => 'required|exists:medical_patients,id',
            'user_id_medecin' => 'required|exists:users,id',
            'date' => 'required|date',
            'heure' => 'required',
            'motif' => 'nullable|string'
        ]);
        
        $date_heure = Carbon::parse($request->date . ' ' . $request->heure);
        
        $rendezvous = MedicalRendezVous::create([
            'patient_id' => $request->patient_id,
            'user_id_medecin' => $request->user_id_medecin,
            'date_heure' => $date_heure,
            'statut' => 'en_attente',
            'motif' => $request->motif,
        ]);
        
        try {
            $patient = $rendezvous->patient->user;
            Mail::to($patient->email)->send(new RendezVousConfirme($rendezvous));
        } catch(\Exception $e) {
            // Continue même si l'email échoue
        }
        
        return redirect()->route('rendezvous.index')->with('success', 'Rendez-vous créé avec succès');
    }
    
    // Formulaire de modification
    public function edit($id)
    {
        $rdv = MedicalRendezVous::findOrFail($id);
        $patients = MedicalPatient::with('user')->get();
        $medecins = User::where('role', 'medecin')->get();
        
        $date = Carbon::parse($rdv->date_heure)->format('Y-m-d');
        $heure = Carbon::parse($rdv->date_heure)->format('H:i');
        
        return view('rendezvous.edit', compact('rdv', 'patients', 'medecins', 'date', 'heure'));
    }
    
    // Mettre à jour un rendez-vous
    public function update(Request $request, $id)
    {
        $rdv = MedicalRendezVous::findOrFail($id);
        
        $request->validate([
            'patient_id' => 'required|exists:medical_patients,id',
            'user_id_medecin' => 'required|exists:users,id',
            'date' => 'required|date',
            'heure' => 'required',
            'statut' => 'required|in:en_attente,confirme,annule,termine',
            'motif' => 'nullable|string'
        ]);
        
        $date_heure = Carbon::parse($request->date . ' ' . $request->heure);
        
        $rdv->update([
            'patient_id' => $request->patient_id,
            'user_id_medecin' => $request->user_id_medecin,
            'date_heure' => $date_heure,
            'statut' => $request->statut,
            'motif' => $request->motif,
        ]);
        
        return redirect()->route('rendezvous.index')->with('success', 'Rendez-vous modifié');
    }
    
    // Supprimer un rendez-vous
    public function destroy($id)
    {
        $rdv = MedicalRendezVous::findOrFail($id);
        $rdv->delete();
        
        return redirect()->route('rendezvous.index')->with('success', 'Rendez-vous supprimé');
    }
    
    // Changer le statut (AJAX)
    public function updateStatut(Request $request, $id)
    {
        $rdv = MedicalRendezVous::findOrFail($id);
        $rdv->statut = $request->statut;
        $rdv->save();
        
        if($request->ajax()) {
            return response()->json(['success' => true]);
        }
        
        return redirect()->route('rendezvous.index')->with('success', 'Statut mis à jour');
    }
    
    // Calendrier des rendez-vous
    public function calendar()
    {
        $evenements = MedicalRendezVous::with(['patient.user', 'medecin'])->get();
        
        $events = [];
        foreach($evenements as $rdv) {
            $events[] = [
                'id' => $rdv->id,
                'title' => $rdv->patient->user->nom . ' ' . $rdv->patient->user->prenom . ' - Dr.' . $rdv->medecin->nom,
                'start' => $rdv->date_heure,
                'color' => $rdv->statut == 'confirme' ? 'green' : ($rdv->statut == 'annule' ? 'red' : 'orange')
            ];
        }
        
        return view('rendezvous.calendar', compact('events'));
    }
}